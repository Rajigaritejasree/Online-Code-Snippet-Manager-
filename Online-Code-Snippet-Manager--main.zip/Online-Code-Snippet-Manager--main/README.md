# Online Code Snippet Manager

A professional, full-stack web application designed for programmers to catalog, organize, search, and manage reusable code blocks, SQL scripts, algorithms, and configurations.

Built with **Java Spring Boot**, **Spring Security with JWT**, **Spring Data JPA**, **MySQL**, and **React.js styled with Tailwind CSS**.

---

## 📁 1. Project Folder Structure

### Backend (Java / Maven)
```text
code-snippet-manager/
│
├── pom.xml                                     # Maven Dependency Manifest
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── example/
│   │   │           └── codesnippetmanager/
│   │   │               │
│   │   │               ├── CodeSnippetManagerApplication.java  # Main Bootstrap Entry
│   │   │               │
│   │   │               ├── config/
│   │   │               │   └── (Security configs mapped to web policies)
│   │   │               │
│   │   │               ├── controller/
│   │   │               │   ├── AuthController.java      # Auth APIs
│   │   │               │   ├── SnippetController.java   # Snippets CRUD APIs
│   │   │               │   ├── CategoryController.java  # Categories APIs
│   │   │               │   └── AdminController.java     # Admin Accounts APIs
│   │   │               │
│   │   │               ├── service/
│   │   │               │   ├── UserService.java         # Register / Login / Profile Service
│   │   │               │   └── SnippetService.java      # Snippet CRUD / Search Service
│   │   │               │
│   │   │               ├── repository/
│   │   │               │   ├── UserRepository.java      # User DB Interface
│   │   │               │   ├── SnippetRepository.java   # Snippets search DB Interface
│   │   │               │   └── CategoryRepository.java  # Categories DB Interface
│   │   │               │
│   │   │               ├── entity/
│   │   │               │   ├── User.java                # Hibernate User Model
│   │   │               │   ├── Snippet.java             # Hibernate Snippet Model
│   │   │               │   ├── Category.java            # Hibernate Category Model
│   │   │               │   └── Role.java                # Role Enum (USER, ADMIN)
│   │   │               │
│   │   │               ├── dto/
│   │   │               │   ├── RegisterRequest.java     # Auth payloads
│   │   │               │   ├── LoginRequest.java
│   │   │               │   ├── AuthResponse.java
│   │   │               │   ├── UserDTO.java             # Sanitized user delivery DTO
│   │   │               │   └── SnippetDTO.java          # Snippet payload mapping DTO
│   │   │               │
│   │   │               ├── security/
│   │   │               │   ├── JwtTokenProvider.java    # Key signing & decrypts
│   │   │               │   ├── JwtAuthenticationFilter.java  # Request JWT filter
│   │   │               │   └── WebSecurityConfig.java   # Spring Security Policies
│   │   │               │
│   │   │               └── exception/
│   │   │                   └── GlobalExceptionHandler.java  # Rest Exception Mapper
│   │   │
│   │   └── resources/
│   │       ├── application.properties          # Database, Hibernate, Ports & Keys
│   │       └── schema.sql                      # Database installation & Seed data
```

### Frontend (React / Vite)
```text
src/
├── main.tsx             # Entry Bootstrap
├── App.tsx              # Root controller with dynamic hash-routing
├── index.css            # Global style definitions & scrollbar styles
├── types.ts             # Shared type interfaces (User, Snippet, AuthState)
│
├── components/
│   └── Navbar.tsx       # Dynamic responsive navigation bar
│
└── pages/
    ├── Home.tsx         # Guest Landing / Search Repository Dashboard
    ├── Login.tsx        # JWT Sign In + Seed Accounts panel
    ├── Register.tsx     # Client-validated user enrollment
    ├── Dashboard.tsx    # User Profile / Private lists / Code statistics
    ├── AddSnippet.tsx   # Code logger with concept selectors
    ├── ViewSnippet.tsx  # Code details view + Clipboard copying
    ├── EditSnippet.tsx  # Code revision panel
    └── AdminDashboard.tsx # Audits + Category setup + Account purges
```

---

## 🛢️ 2. MySQL Queries (`schema.sql`)

Execute this query block in your MySQL Client (like Workbench or CLI) to set up your database environment before starting the Java application:

```sql
-- Create Database
CREATE DATABASE IF NOT EXISTS code_snippet_manager;
USE code_snippet_manager;

-- Table: users
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'USER',
    bio TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: categories
CREATE TABLE IF NOT EXISTS categories (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: snippets
CREATE TABLE IF NOT EXISTS snippets (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    programming_language VARCHAR(50) NOT NULL,
    code_content TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_id BIGINT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Seed Categories
INSERT INTO categories (name) VALUES ('Java') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO categories (name) VALUES ('Python') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO categories (name) VALUES ('SQL') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO categories (name) VALUES ('Web Development') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO categories (name) VALUES ('Data Structures') ON DUPLICATE KEY UPDATE name=name;

-- Seed Default Accounts (BCrypt Password is encrypted with salt)
-- admin@snippet.com / admin123
INSERT INTO users (username, email, password, role, bio) 
VALUES ('admin', 'admin@snippet.com', '$2a$10$8.Kclm2L3C9yN2GfG0V98euD/6XfeQ6q6b30WId8R98z0f1i1W3G2', 'ADMIN', 'System Administrator')
ON DUPLICATE KEY UPDATE username=username;

-- user@snippet.com / user123
INSERT INTO users (username, email, password, role, bio) 
VALUES ('developer_pro', 'user@snippet.com', '$2a$10$7vF0R7fRz7B.R1N0m1P8Gef/I76Z99Q6VFeSId9D6X6R6g0C7b5Y2', 'USER', 'Passionate Full Stack Java Developer')
ON DUPLICATE KEY UPDATE username=username;
```

---

## ⚙️ 3. `application.properties`

Add this content into `/src/main/resources/application.properties` of the Spring Boot folder:

```properties
server.port=8080

# Database Configuration (MySQL)
spring.datasource.url=jdbc:mysql://localhost:3306/code_snippet_manager?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=root1234
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver

# JPA & Hibernate Settings
spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.format_sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect

# JWT Cryptography Key
app.jwt.secret=9a6761137113112a2a2221234123abcdabcd4321fedcba0987654321fedcba09
app.jwt.expiration-ms=604800000
```

---

## 🧪 4. API Testing using Postman

You can test all endpoints through Postman using the specifications below.

### I. User Registration
* **Method**: `POST`
* **URL**: `http://localhost:8080/api/auth/register`
* **Body** (JSON):
```json
{
  "username": "coder_john",
  "email": "john@snippet.com",
  "password": "securepassword123",
  "role": "USER"
}
```

### II. User Sign In (Obtain JWT)
* **Method**: `POST`
* **URL**: `http://localhost:8080/api/auth/login`
* **Body** (JSON):
```json
{
  "email": "john@snippet.com",
  "password": "securepassword123"
}
```
* **Response**: Returns a token key in `"token"`. Copy this value!

### III. List Snippets (Requires JWT Auth Header)
* **Method**: `GET`
* **URL**: `http://localhost:8080/api/snippets`
* **Headers**:
  * `Authorization`: `Bearer <COPIED_JWT_TOKEN>`

### IV. Log New Snippet
* **Method**: `POST`
* **URL**: `http://localhost:8080/api/snippets`
* **Headers**:
  * `Authorization`: `Bearer <COPIED_JWT_TOKEN>`
* **Body** (JSON):
```json
{
  "title": "Quick Hash Map Lookup",
  "description": "Example fetching custom configurations",
  "programmingLanguage": "Java",
  "codeContent": "Map<String, String> config = new HashMap<>();\nconfig.getOrDefault(\"timeout\", \"3000\");",
  "category": "Java"
}
```

### V. Advanced Query Search
* **Method**: `GET`
* **URL**: `http://localhost:8080/api/snippets/search?query=HashMap&language=Java&category=Java`
* **Headers**:
  * `Authorization`: `Bearer <COPIED_JWT_TOKEN>`

---

## 📋 5. Project Report Contents

### Abstract
Modern software developers utilize complex frameworks, boilerplate layouts, and intricate algorithms daily. Finding, recalling, and sharing recurring snippets of code takes significant cognitive energy. The **Online Code Snippet Manager** offers a centralized, highly indexable personal developer repository, allowing programmers to save, catalog, search, and copy key configurations and scripts from a secure dashboard.

### Core Architecture
1. **Frontend Layer (Single Page React UI)**: Uses a highly responsive UI with deep routing. Connects to backend web APIs using `Axios` and dynamically stores JWT authorization headers on the client.
2. **REST API Interface Layer**: Standardizes stateless endpoints under `/api/*` for structured, cross-origin web requests.
3. **Security Interceptors Layer (Spring Security + JWT)**: Intercepts requests on protected endpoints, decodes headers, validates claims, and maps user authority groups (USER, ADMIN) to standard request scopes.
4. **Service & Persistence Layers (Hibernate JPA + MySQL)**: Maps high-performance relational tables, implements flexible JPQL search models, and triggers cascade purges safely.

---

## 📊 6. Slide-Show (PPT) Content (5 Slides)

### Slide 1: Title & Overview
* **Title**: Online Code Snippet Manager
* **Subtitle**: Centralized Developer Code Repository System
* **Bullet Points**:
  * **Core Goal**: Empower developers to save, search, and recall reusable scripts.
  * **Full-Stack Technologies**: Spring Boot, Spring Security (JWT), MySQL, and React.js.
  * **Primary Value**: Lowers cognitive fatigue and prevents code duplication across projects.

### Slide 2: Technology Architecture & Stack
* **Title**: Component-Based Architecture
* **Bullet Points**:
  * **Frontend**: Responsive Single-Page UI powered by React, Tailwind CSS, and Axios API brokers.
  * **Security Layer**: Spring Security with JWT tokens, password hashing via BCrypt, and Role-Based Access Control (USER/ADMIN).
  * **Data Access & Storage**: Spring Data JPA Hibernate ORM with persistent MySQL Relational DB schemas.

### Slide 3: Functional Feature Set
* **Title**: Key Application Modules
* **Bullet Points**:
  * **Programmer Identity**: Self-service profile editing and bio updates.
  * **Dynamic Snippets CRUD**: Store codes with descriptions, language designations, and concept categories.
  * **Flexible Query Engines**: Integrated filter queries supporting real-time matching across keywords, categories, and tags.
  * **Interactive Code Cards**: Monospace visual viewports with instant copy-to-clipboard actions.

### Slide 4: System Administration & Governance
* **Title**: Administrative Controls & Moderation
* **Bullet Points**:
  * **User Management Dashboard**: Admins can audit all registered accounts, emails, and snippet volumes.
  * **Database Cleanups**: Capability to delete accounts (cascading all associated data) or isolate unwanted code blocks.
  * **Catalog Configuration**: Dynamic category additions (e.g., Spring Security, AWS) made globally accessible to users.

### Slide 5: Local Execution & Setups
* **Title**: 5-Step System Execution
* **Bullet Points**:
  * **Step 1**: Install and start MySQL Server. Initialize DB schema using `schema.sql`.
  * **Step 2**: Insert credentials and datasource strings into `application.properties`.
  * **Step 3**: Compile and start Java backend: `mvn spring-boot:run`.
  * **Step 4**: Install React components and build files: `npm install` followed by `npm run build`.
  * **Step 5**: Launch web client dev mode: `npm run dev` and navigate to `http://localhost:3000`.

---

## 🚀 7. Steps to Run the Project Locally

### Prerequisites
* Java JDK 17 or higher
* Apache Maven
* Node.js v18 or higher (with npm)
* MySQL Community Server 8.x

### Execution Sequence

#### 1. Setup the Relational Database
* Start your local MySQL instance.
* Log into the client and run the queries inside the `schema.sql` file.

#### 2. Launch the Spring Boot Backend
* Navigate to the Spring Boot root directory (holding `pom.xml`).
* Configure the database connection passwords in `/src/main/resources/application.properties`.
* Run Maven compilation:
  ```bash
  mvn clean install
  ```
* Start the server:
  ```bash
  mvn spring-boot:run
  ```
* The backend will bind and run on `http://localhost:8080`.

#### 3. Launch the React Client
* Navigate to the React frontend directory.
* Install node packages:
  ```bash
  npm install
  ```
* Start the client development environment:
  ```bash
  npm run dev
  ```
* Open your browser and navigate to `http://localhost:3000`. You can log in using pre-seeded developer accounts!
