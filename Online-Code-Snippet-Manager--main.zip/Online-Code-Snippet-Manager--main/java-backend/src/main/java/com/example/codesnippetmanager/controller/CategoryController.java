package com.example.codesnippetmanager.controller;

import com.example.codesnippetmanager.service.SnippetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/categories")
@CrossOrigin
public class CategoryController {

    @Autowired
    private SnippetService snippetService;

    @GetMapping
    public ResponseEntity<List<String>> getAllCategories() {
        return ResponseEntity.ok(snippetService.getAllCategories());
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<String>> addCategory(@RequestBody Map<String, String> body) {
        String category = body.get("category");
        return ResponseEntity.ok(snippetService.addCategory(category));
    }

    @DeleteMapping("/{name}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<String>> deleteCategory(@PathVariable String name) {
        return ResponseEntity.ok(snippetService.deleteCategory(name));
    }
}
