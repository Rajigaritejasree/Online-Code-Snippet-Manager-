package com.example.codesnippetmanager.controller;

import com.example.codesnippetmanager.dto.SnippetDTO;
import com.example.codesnippetmanager.dto.UserDTO;
import com.example.codesnippetmanager.entity.User;
import com.example.codesnippetmanager.repository.UserRepository;
import com.example.codesnippetmanager.service.SnippetService;
import com.example.codesnippetmanager.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class SnippetController {

    @Autowired
    private SnippetService snippetService;

    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    private Long getCurrentUserId(HttpServletRequest request) {
        // Retrieve custom claim attributes injected by JwtAuthenticationFilter
        Object idAttr = request.getAttribute("currentUserId");
        if (idAttr != null) {
            return Long.valueOf(idAttr.toString());
        }

        // Fallback context lookup
        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User u = userRepository.findByEmail(email).orElseThrow(() -> new IllegalArgumentException("User not found"));
        return u.getId();
    }

    private String getCurrentUserRole(HttpServletRequest request) {
        Object roleAttr = request.getAttribute("currentUserRole");
        if (roleAttr != null) {
            return roleAttr.toString();
        }

        String email = SecurityContextHolder.getContext().getAuthentication().getName();
        User u = userRepository.findByEmail(email).orElseThrow(() -> new IllegalArgumentException("User not found"));
        return u.getRole().name();
    }

    // --- Profile routes ---
    @GetMapping("/users/profile")
    public ResponseEntity<UserDTO> getUserProfile(HttpServletRequest request) {
        Long currentUserId = getCurrentUserId(request);
        return ResponseEntity.ok(userService.getUserProfile(currentUserId));
    }

    @PutMapping("/users/profile")
    public ResponseEntity<UserDTO> updateUserProfile(@RequestBody Map<String, String> body, HttpServletRequest request) {
        Long currentUserId = getCurrentUserId(request);
        String username = body.get("username");
        String bio = body.get("bio");
        return ResponseEntity.ok(userService.updateUserProfile(currentUserId, username, bio));
    }

    // --- Snippets CRUD ---
    @GetMapping("/snippets")
    public ResponseEntity<List<SnippetDTO>> getAllSnippets(HttpServletRequest request) {
        Long currentUserId = getCurrentUserId(request);
        String role = getCurrentUserRole(request);
        return ResponseEntity.ok(snippetService.getAllSnippets(currentUserId, role));
    }

    @PostMapping("/snippets")
    public ResponseEntity<SnippetDTO> createSnippet(@RequestBody SnippetDTO dto, HttpServletRequest request) {
        Long currentUserId = getCurrentUserId(request);
        SnippetDTO created = snippetService.createSnippet(dto, currentUserId);
        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    @GetMapping("/snippets/{id}")
    public ResponseEntity<SnippetDTO> getSnippetById(@PathVariable Long id, HttpServletRequest request) {
        Long currentUserId = getCurrentUserId(request);
        String role = getCurrentUserRole(request);
        return ResponseEntity.ok(snippetService.getSnippetById(id, currentUserId, role));
    }

    @PutMapping("/snippets/{id}")
    public ResponseEntity<SnippetDTO> updateSnippet(@PathVariable Long id, @RequestBody SnippetDTO dto, HttpServletRequest request) {
        Long currentUserId = getCurrentUserId(request);
        String role = getCurrentUserRole(request);
        return ResponseEntity.ok(snippetService.updateSnippet(id, dto, currentUserId, role));
    }

    @DeleteMapping("/snippets/{id}")
    public ResponseEntity<?> deleteSnippet(@PathVariable Long id, HttpServletRequest request) {
        Long currentUserId = getCurrentUserId(request);
        String role = getCurrentUserRole(request);
        snippetService.deleteSnippet(id, currentUserId, role);
        return ResponseEntity.ok().body(Map.of("message", "Snippet deleted successfully"));
    }

    // --- Snippet Search ---
    @GetMapping("/snippets/search")
    public ResponseEntity<List<SnippetDTO>> searchSnippets(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String language,
            @RequestParam(required = false) String category,
            HttpServletRequest request) {
        Long currentUserId = getCurrentUserId(request);
        String role = getCurrentUserRole(request);
        List<SnippetDTO> results = snippetService.searchSnippets(currentUserId, role, query, language, category);
        return ResponseEntity.ok(results);
    }
}
