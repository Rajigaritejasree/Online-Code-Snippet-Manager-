package com.example.codesnippetmanager.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SnippetDTO {
    private Long id;
    private String title;
    private String description;
    private String programmingLanguage;
    private String codeContent;
    private String category;
    private LocalDateTime createdDate;
    private Long userId;
    private String authorName; // optional but useful field for admin dashboards
}
