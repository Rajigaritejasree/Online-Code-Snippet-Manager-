package com.example.codesnippetmanager.entity;

public enum Role {
    USER,
    ADMIN
}
