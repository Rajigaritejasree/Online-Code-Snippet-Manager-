package com.example.codesnippetmanager.repository;

import com.example.codesnippetmanager.entity.Snippet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SnippetRepository extends JpaRepository<Snippet, Long> {
    
    List<Snippet> findByUserIdOrderByCreatedDateDesc(Long userId);
    
    List<Snippet> findAllByOrderByCreatedDateDesc();
    
    long countByUserId(Long userId);

    @Query("SELECT s FROM Snippet s WHERE " +
           "(:userId IS NULL OR s.user.id = :userId) AND " +
           "(:query IS NULL OR LOWER(s.title) LIKE LOWER(CONCAT('%', :query, '%')) " +
           "OR LOWER(s.description) LIKE LOWER(CONCAT('%', :query, '%')) " +
           "OR LOWER(s.codeContent) LIKE LOWER(CONCAT('%', :query, '%'))) AND " +
           "(:language IS NULL OR LOWER(s.programmingLanguage) = LOWER(:language)) AND " +
           "(:category IS NULL OR LOWER(s.category) = LOWER(:category)) " +
           "ORDER BY s.createdDate DESC")
    List<Snippet> searchSnippets(
        @Param("userId") Long userId,
        @Param("query") String query,
        @Param("language") String language,
        @Param("category") String category
    );
}
