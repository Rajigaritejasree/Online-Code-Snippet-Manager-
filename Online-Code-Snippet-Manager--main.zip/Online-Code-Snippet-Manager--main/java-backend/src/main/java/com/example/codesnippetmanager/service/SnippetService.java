package com.example.codesnippetmanager.service;

import com.example.codesnippetmanager.dto.SnippetDTO;
import com.example.codesnippetmanager.entity.Category;
import com.example.codesnippetmanager.entity.Role;
import com.example.codesnippetmanager.entity.Snippet;
import com.example.codesnippetmanager.entity.User;
import com.example.codesnippetmanager.repository.CategoryRepository;
import com.example.codesnippetmanager.repository.SnippetRepository;
import com.example.codesnippetmanager.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SnippetService {

    @Autowired
    private SnippetRepository snippetRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Transactional
    public SnippetDTO createSnippet(SnippetDTO dto, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        Snippet snippet = Snippet.builder()
                .title(dto.getTitle())
                .description(dto.getDescription())
                .programmingLanguage(dto.getProgrammingLanguage())
                .codeContent(dto.getCodeContent())
                .category(dto.getCategory())
                .user(user)
                .build();

        Snippet saved = snippetRepository.save(snippet);
        return convertToDTO(saved);
    }

    public List<SnippetDTO> getAllSnippets(Long currentUserId, String role) {
        List<Snippet> snippets;
        if (role.equals("ADMIN")) {
            snippets = snippetRepository.findAllByOrderByCreatedDateDesc();
        } else {
            snippets = snippetRepository.findByUserIdOrderByCreatedDateDesc(currentUserId);
        }
        return snippets.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    public SnippetDTO getSnippetById(Long id, Long currentUserId, String role) {
        Snippet snippet = snippetRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Snippet not found"));

        // Access control check
        if (!role.equals("ADMIN") && !snippet.getUser().getId().equals(currentUserId)) {
            throw new AccessDeniedException("Access denied. You can only view your own snippets.");
        }

        return convertToDTO(snippet);
    }

    @Transactional
    public SnippetDTO updateSnippet(Long id, SnippetDTO dto, Long currentUserId, String role) {
        Snippet snippet = snippetRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Snippet not found"));

        // Access control check
        if (!role.equals("ADMIN") && !snippet.getUser().getId().equals(currentUserId)) {
            throw new AccessDeniedException("Access denied. You can only update your own snippets.");
        }

        snippet.setTitle(dto.getTitle());
        snippet.setDescription(dto.getDescription());
        snippet.setProgrammingLanguage(dto.getProgrammingLanguage());
        snippet.setCodeContent(dto.getCodeContent());
        snippet.setCategory(dto.getCategory());

        Snippet updated = snippetRepository.save(snippet);
        return convertToDTO(updated);
    }

    @Transactional
    public void deleteSnippet(Long id, Long currentUserId, String role) {
        Snippet snippet = snippetRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Snippet not found"));

        // Access control check
        if (!role.equals("ADMIN") && !snippet.getUser().getId().equals(currentUserId)) {
            throw new AccessDeniedException("Access denied. You can only delete your own snippets.");
        }

        snippetRepository.delete(snippet);
    }

    public List<SnippetDTO> searchSnippets(Long currentUserId, String role, String query, String language, String category) {
        Long filterUserId = role.equals("ADMIN") ? null : currentUserId;
        
        // Convert empty parameters to null so JPQL can safely handle them
        String q = (query == null || query.trim().isEmpty()) ? null : query.trim();
        String lang = (language == null || language.trim().isEmpty()) ? null : language.trim();
        String cat = (category == null || category.trim().isEmpty()) ? null : category.trim();

        List<Snippet> results = snippetRepository.searchSnippets(filterUserId, q, lang, cat);
        return results.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    // Category Methods
    public List<String> getAllCategories() {
        return categoryRepository.findAll().stream()
                .map(Category::getName)
                .collect(Collectors.toList());
    }

    @Transactional
    public List<String> addCategory(String name) {
        if (categoryRepository.existsByNameIgnoreCase(name)) {
            throw new IllegalArgumentException("Category already exists");
        }
        categoryRepository.save(Category.builder().name(name).build());
        return getAllCategories();
    }

    @Transactional
    public List<String> deleteCategory(String name) {
        Category category = categoryRepository.findByNameIgnoreCase(name)
                .orElseThrow(() -> new IllegalArgumentException("Category not found"));
        categoryRepository.delete(category);
        return getAllCategories();
    }

    private SnippetDTO convertToDTO(Snippet s) {
        return SnippetDTO.builder()
                .id(s.getId())
                .title(s.getTitle())
                .description(s.getDescription())
                .programmingLanguage(s.getProgrammingLanguage())
                .codeContent(s.getCodeContent())
                .category(s.getCategory())
                .createdDate(s.getCreatedDate())
                .userId(s.getUser().getId())
                .authorName(s.getUser().getUsername())
                .build();
    }
}
