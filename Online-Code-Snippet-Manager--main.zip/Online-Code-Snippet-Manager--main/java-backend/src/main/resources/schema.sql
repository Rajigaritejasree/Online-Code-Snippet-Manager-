-- Create Database
CREATE DATABASE IF NOT EXISTS code_snippet_manager;
USE code_snippet_manager;

-- Table: users
CREATE TABLE IF NOT EXISTS users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'USER',
    bio TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: categories
CREATE TABLE IF NOT EXISTS categories (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table: snippets
CREATE TABLE IF NOT EXISTS snippets (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    description TEXT,
    programming_language VARCHAR(50) NOT NULL,
    code_content TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_id BIGINT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Seed Categories
INSERT INTO categories (name) VALUES ('Java') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO categories (name) VALUES ('Python') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO categories (name) VALUES ('SQL') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO categories (name) VALUES ('Web Development') ON DUPLICATE KEY UPDATE name=name;
INSERT INTO categories (name) VALUES ('Data Structures') ON DUPLICATE KEY UPDATE name=name;

-- Seed Default Admin and User (Passes are: admin123, user123 encrypted with BCrypt)
-- Password for admin: admin123 -> $2a$10$8.Kclm2L3C9yN2GfG0V98euD/6XfeQ6q6b30WId8R98z0f1i1W3G2
-- Password for user: user123 -> $2a$10$7vF0R7fRz7B.R1N0m1P8Gef/I76Z99Q6VFeSId9D6X6R6g0C7b5Y2
INSERT INTO users (username, email, password, role, bio) 
VALUES ('admin', 'admin@snippet.com', '$2a$10$8.Kclm2L3C9yN2GfG0V98euD/6XfeQ6q6b30WId8R98z0f1i1W3G2', 'ADMIN', 'System Administrator')
ON DUPLICATE KEY UPDATE username=username;

INSERT INTO users (username, email, password, role, bio) 
VALUES ('developer_pro', 'user@snippet.com', '$2a$10$7vF0R7fRz7B.R1N0m1P8Gef/I76Z99Q6VFeSId9D6X6R6g0C7b5Y2', 'USER', 'Passionate Full Stack Java Developer')
ON DUPLICATE KEY UPDATE username=username;
