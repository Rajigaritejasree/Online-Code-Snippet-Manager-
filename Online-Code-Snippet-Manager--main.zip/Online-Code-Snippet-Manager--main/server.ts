import express from "express";
import path from "path";
import fs from "fs";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { createServer as createViteServer } from "vite";

const PORT = 3000;
const JWT_SECRET = "super_secret_key_snippet_manager_jwt_tokens_2026";

// Path for a JSON-based local store to survive restarts beautifully
const DATA_FILE = path.join(process.cwd(), "data.json");

// Ensure default data exists
const defaultCategories = ["Java", "Python", "SQL", "Web Development", "Data Structures"];
interface User {
  id: string;
  username: string;
  email: string;
  passwordHash: string;
  role: "USER" | "ADMIN";
  bio?: string;
}

interface Snippet {
  id: string;
  title: string;
  description: string;
  programmingLanguage: string;
  codeContent: string;
  category: string;
  createdDate: string;
  userId: string;
}

interface AppData {
  users: User[];
  snippets: Snippet[];
  categories: string[];
}

function loadData(): AppData {
  if (fs.existsSync(DATA_FILE)) {
    try {
      const content = fs.readFileSync(DATA_FILE, "utf-8");
      const parsed = JSON.parse(content);
      return {
        users: parsed.users || [],
        snippets: parsed.snippets || [],
        categories: parsed.categories || defaultCategories,
      };
    } catch (e) {
      console.error("Error reading data.json", e);
    }
  }

  // Create default with an admin account
  const salt = bcrypt.genSaltSync(10);
  const defaultAdminPasswordHash = bcrypt.hashSync("admin123", salt);
  const defaultUserPasswordHash = bcrypt.hashSync("user123", salt);

  const initialData: AppData = {
    users: [
      {
        id: "admin-id",
        username: "admin",
        email: "admin@snippet.com",
        passwordHash: defaultAdminPasswordHash,
        role: "ADMIN",
        bio: "System Administrator",
      },
      {
        id: "user-id",
        username: "developer_pro",
        email: "user@snippet.com",
        passwordHash: defaultUserPasswordHash,
        role: "USER",
        bio: "Passionate Full Stack Java Developer",
      },
    ],
    snippets: [
      {
        id: "snippet-1",
        title: "Spring Boot REST Controller Example",
        description: "A standard Spring Boot REST controller with basic CRUD mapping.",
        programmingLanguage: "Java",
        codeContent: `@RestController\n@RequestMapping("/api/snippets")\npublic class SnippetController {\n\n    @Autowired\n    private SnippetService snippetService;\n\n    @GetMapping\n    public ResponseEntity<List<SnippetDTO>> getAllSnippets() {\n        return ResponseEntity.ok(snippetService.findAll());\n    }\n}`,
        category: "Java",
        createdDate: "2026-06-24T08:00:00.000Z",
        userId: "user-id",
      },
      {
        id: "snippet-2",
        title: "Fast API Route Handler",
        description: "Simple API endpoint in FastAPI Python.",
        programmingLanguage: "Python",
        codeContent: "from fastapi import FastAPI\n\napp = FastAPI()\n\n@app.get('/api/health')\ndef health_check():\n    return {'status': 'healthy'}",
        category: "Python",
        createdDate: "2026-06-24T08:15:00.000Z",
        userId: "user-id",
      },
      {
        id: "snippet-3",
        title: "Bresenham's Line Algorithm",
        description: "Standard computer graphics algorithm to plot a straight line.",
        programmingLanguage: "Java",
        codeContent: `public void drawLine(int x0, int y0, int x1, int y1) {\n    int dx = Math.abs(x1 - x0);\n    int dy = Math.abs(y1 - y0);\n    int sx = x0 < x1 ? 1 : -1;\n    int sy = y0 < y1 ? 1 : -1;\n    int err = dx - dy;\n    \n    while (true) {\n        plot(x0, y0);\n        if (x0 == x1 && y0 == y1) break;\n        int e2 = 2 * err;\n        if (e2 > -dy) {\n            err -= dy;\n            x0 += sx;\n        }\n        if (e2 < dx) {\n            err += dx;\n            y0 += sy;\n        }\n    }\n}`,
        category: "Data Structures",
        createdDate: "2026-06-24T08:30:00.000Z",
        userId: "admin-id",
      },
    ],
    categories: defaultCategories,
  };

  saveData(initialData);
  return initialData;
}

function saveData(data: AppData) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
}

async function startServer() {
  const app = express();
  app.use(express.json());

  const data = loadData();

  // Helper middleware for auth
  function authenticateToken(req: any, res: any, next: any) {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
      return res.status(401).json({ error: "Access token required" });
    }

    jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
      if (err) {
        return res.status(403).json({ error: "Invalid or expired token" });
      }
      req.user = decoded;
      next();
    });
  }

  // --- API Routes ---

  // Auth: Register
  app.post("/api/auth/register", (req, res) => {
    try {
      const { username, email, password, role } = req.body;

      if (!username || !email || !password) {
        return res.status(400).json({ error: "Please fill in all fields" });
      }

      // Check if email or username exists
      const existingEmail = data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
      const existingUser = data.users.find((u) => u.username.toLowerCase() === username.toLowerCase());

      if (existingEmail || existingUser) {
        return res.status(400).json({ error: "Username or email is already registered" });
      }

      const salt = bcrypt.genSaltSync(10);
      const passwordHash = bcrypt.hashSync(password, salt);

      const newUser: User = {
        id: "user-" + Date.now(),
        username,
        email,
        passwordHash,
        role: role === "ADMIN" ? "ADMIN" : "USER",
        bio: "",
      };

      data.users.push(newUser);
      saveData(data);

      res.status(201).json({ message: "Registration successful" });
    } catch (err: any) {
      res.status(500).json({ error: "Registration failed: " + err.message });
    }
  });

  // Auth: Login
  app.post("/api/auth/login", (req, res) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: "Please provide email and password" });
      }

      const user = data.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
      if (!user) {
        return res.status(401).json({ error: "Invalid email or password" });
      }

      const isPasswordMatch = bcrypt.compareSync(password, user.passwordHash);
      if (!isPasswordMatch) {
        return res.status(401).json({ error: "Invalid email or password" });
      }

      // Generate JWT Token
      const token = jwt.sign(
        { id: user.id, username: user.username, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: "7d" }
      );

      res.json({
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role,
          bio: user.bio,
        },
      });
    } catch (err: any) {
      res.status(500).json({ error: "Login failed: " + err.message });
    }
  });

  // User Profile
  app.get("/api/users/profile", authenticateToken, (req: any, res) => {
    const user = data.users.find((u) => u.id === req.user.id);
    if (!user) {
      return res.status(404).json({ error: "User profile not found" });
    }
    res.json({
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      bio: user.bio,
    });
  });

  // Update Profile
  app.put("/api/users/profile", authenticateToken, (req: any, res) => {
    const userIdx = data.users.findIndex((u) => u.id === req.user.id);
    if (userIdx === -1) {
      return res.status(404).json({ error: "User profile not found" });
    }

    const { username, bio } = req.body;
    if (username) {
      data.users[userIdx].username = username;
    }
    data.users[userIdx].bio = bio || "";

    saveData(data);

    res.json({
      message: "Profile updated successfully",
      user: {
        id: data.users[userIdx].id,
        username: data.users[userIdx].username,
        email: data.users[userIdx].email,
        role: data.users[userIdx].role,
        bio: data.users[userIdx].bio,
      },
    });
  });

  // Snippets Search API (Must be declared BEFORE specific GET /api/snippets/:id)
  app.get("/api/snippets/search", authenticateToken, (req: any, res) => {
    try {
      const { query, language, category } = req.query;

      let filtered = data.snippets;

      // Regular users only see their own snippets, admin can see all
      if (req.user.role !== "ADMIN") {
        filtered = filtered.filter((s) => s.userId === req.user.id);
      }

      if (query) {
        const lowerQ = query.toString().toLowerCase();
        filtered = filtered.filter(
          (s) =>
            s.title.toLowerCase().includes(lowerQ) ||
            s.description.toLowerCase().includes(lowerQ) ||
            s.codeContent.toLowerCase().includes(lowerQ)
        );
      }

      if (language) {
        const lowerL = language.toString().toLowerCase();
        filtered = filtered.filter((s) => s.programmingLanguage.toLowerCase() === lowerL);
      }

      if (category) {
        const lowerC = category.toString().toLowerCase();
        filtered = filtered.filter((s) => s.category.toLowerCase() === lowerC);
      }

      res.json(filtered);
    } catch (err: any) {
      res.status(500).json({ error: "Search failed: " + err.message });
    }
  });

  // Get Snippets
  app.get("/api/snippets", authenticateToken, (req: any, res) => {
    // If Admin, can view all. If User, only view own
    if (req.user.role === "ADMIN") {
      res.json(data.snippets);
    } else {
      const userSnippets = data.snippets.filter((s) => s.userId === req.user.id);
      res.json(userSnippets);
    }
  });

  // Get Single Snippet
  app.get("/api/snippets/:id", authenticateToken, (req: any, res) => {
    const snippet = data.snippets.find((s) => s.id === req.params.id);

    if (!snippet) {
      return res.status(404).json({ error: "Snippet not found" });
    }

    // Access control: Only Admin or snippet owner
    if (req.user.role !== "ADMIN" && snippet.userId !== req.user.id) {
      return res.status(403).json({ error: "Access denied. Not your snippet." });
    }

    res.json(snippet);
  });

  // Create Snippet
  app.post("/api/snippets", authenticateToken, (req: any, res) => {
    try {
      const { title, description, programmingLanguage, codeContent, category } = req.body;

      if (!title || !programmingLanguage || !codeContent || !category) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const newSnippet: Snippet = {
        id: "snippet-" + Date.now(),
        title,
        description: description || "",
        programmingLanguage,
        codeContent,
        category,
        createdDate: new Date().toISOString(),
        userId: req.user.id,
      };

      data.snippets.unshift(newSnippet); // Add to the top
      saveData(data);

      res.status(201).json(newSnippet);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to create snippet: " + err.message });
    }
  });

  // Update Snippet
  app.put("/api/snippets/:id", authenticateToken, (req: any, res) => {
    try {
      const idx = data.snippets.findIndex((s) => s.id === req.params.id);

      if (idx === -1) {
        return res.status(404).json({ error: "Snippet not found" });
      }

      const snippet = data.snippets[idx];

      // Access control: Only owner or admin can update
      if (req.user.role !== "ADMIN" && snippet.userId !== req.user.id) {
        return res.status(403).json({ error: "Access denied. Not your snippet." });
      }

      const { title, description, programmingLanguage, codeContent, category } = req.body;

      if (title) snippet.title = title;
      if (description !== undefined) snippet.description = description;
      if (programmingLanguage) snippet.programmingLanguage = programmingLanguage;
      if (codeContent) snippet.codeContent = codeContent;
      if (category) snippet.category = category;

      saveData(data);

      res.json(snippet);
    } catch (err: any) {
      res.status(500).json({ error: "Failed to update snippet: " + err.message });
    }
  });

  // Delete Snippet
  app.delete("/api/snippets/:id", authenticateToken, (req: any, res) => {
    try {
      const idx = data.snippets.findIndex((s) => s.id === req.params.id);

      if (idx === -1) {
        return res.status(404).json({ error: "Snippet not found" });
      }

      const snippet = data.snippets[idx];

      // Access control: Only owner or admin can delete
      if (req.user.role !== "ADMIN" && snippet.userId !== req.user.id) {
        return res.status(403).json({ error: "Access denied. Not your snippet." });
      }

      data.snippets.splice(idx, 1);
      saveData(data);

      res.json({ message: "Snippet deleted successfully" });
    } catch (err: any) {
      res.status(500).json({ error: "Failed to delete snippet: " + err.message });
    }
  });

  // Categories Endpoint
  app.get("/api/categories", authenticateToken, (req, res) => {
    res.json(data.categories);
  });

  // Admin Manage Categories (Add)
  app.post("/api/categories", authenticateToken, (req: any, res) => {
    if (req.user.role !== "ADMIN") {
      return res.status(403).json({ error: "Admin resource only" });
    }

    const { category } = req.body;
    if (!category) {
      return res.status(400).json({ error: "Category name is required" });
    }

    if (data.categories.some((c) => c.toLowerCase() === category.toLowerCase())) {
      return res.status(400).json({ error: "Category already exists" });
    }

    data.categories.push(category);
    saveData(data);

    res.status(201).json(data.categories);
  });

  // Admin Manage Categories (Delete)
  app.delete("/api/categories/:name", authenticateToken, (req: any, res) => {
    if (req.user.role !== "ADMIN") {
      return res.status(403).json({ error: "Admin resource only" });
    }

    const name = req.params.name;
    const index = data.categories.findIndex((c) => c.toLowerCase() === name.toLowerCase());

    if (index === -1) {
      return res.status(404).json({ error: "Category not found" });
    }

    data.categories.splice(index, 1);
    saveData(data);

    res.json(data.categories);
  });

  // Admin View All Users
  app.get("/api/admin/users", authenticateToken, (req: any, res) => {
    if (req.user.role !== "ADMIN") {
      return res.status(403).json({ error: "Admin access only" });
    }

    // Map users to remove password hash
    const safeUsers = data.users.map((u) => ({
      id: u.id,
      username: u.username,
      email: u.email,
      role: u.role,
      bio: u.bio || "",
      snippetsCount: data.snippets.filter((s) => s.userId === u.id).length,
    }));

    res.json(safeUsers);
  });

  // Admin Delete User
  app.delete("/api/admin/users/:id", authenticateToken, (req: any, res) => {
    if (req.user.role !== "ADMIN") {
      return res.status(403).json({ error: "Admin access only" });
    }

    if (req.params.id === req.user.id) {
      return res.status(400).json({ error: "You cannot delete yourself" });
    }

    const index = data.users.findIndex((u) => u.id === req.params.id);
    if (index === -1) {
      return res.status(404).json({ error: "User not found" });
    }

    // Delete user
    data.users.splice(index, 1);
    // Delete all snippets of that user
    data.snippets = data.snippets.filter((s) => s.userId !== req.params.id);

    saveData(data);

    res.json({ message: "User and their snippets deleted successfully" });
  });

  // --- Serve Client/SPA assets ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Server] Running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
