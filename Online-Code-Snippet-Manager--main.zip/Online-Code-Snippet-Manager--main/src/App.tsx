import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import AddSnippet from "./pages/AddSnippet";
import ViewSnippet from "./pages/ViewSnippet";
import EditSnippet from "./pages/EditSnippet";
import AdminDashboard from "./pages/AdminDashboard";
import { User, AuthState } from "./types";

export default function App() {
  // Authentication State
  const [authState, setAuthState] = useState<AuthState>({
    token: localStorage.getItem("jwt_token"),
    user: (() => {
      const savedUser = localStorage.getItem("logged_user");
      try {
        return savedUser ? JSON.parse(savedUser) : null;
      } catch {
        return null;
      }
    })(),
  });

  // Client Routing State
  const [hash, setHash] = useState(window.location.hash || "#/");

  useEffect(() => {
    const handleHashChange = () => {
      setHash(window.location.hash || "#/");
    };
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  const navigate = (path: string) => {
    window.location.hash = path;
  };

  const handleLoginSuccess = (token: string, user: User) => {
    localStorage.setItem("jwt_token", token);
    localStorage.setItem("logged_user", JSON.stringify(user));
    setAuthState({ token, user });
    navigate("#/dashboard");
  };

  const handleLogout = () => {
    localStorage.removeItem("jwt_token");
    localStorage.removeItem("logged_user");
    setAuthState({ token: null, user: null });
    navigate("#/");
  };

  const handleProfileUpdate = (updatedUser: User) => {
    localStorage.setItem("logged_user", JSON.stringify(updatedUser));
    setAuthState((prev) => ({ ...prev, user: updatedUser }));
  };

  // Route Parser
  const parseRoute = () => {
    if (hash === "#/" || !hash) return { name: "home", params: {} };
    if (hash === "#/login") return { name: "login", params: {} };
    if (hash === "#/register") return { name: "register", params: {} };
    if (hash === "#/dashboard") return { name: "dashboard", params: {} };
    if (hash === "#/snippets/add") return { name: "add-snippet", params: {} };
    if (hash === "#/admin") return { name: "admin", params: {} };

    if (hash.startsWith("#/snippets/view/")) {
      const id = hash.substring("#/snippets/view/".length);
      return { name: "view-snippet", params: { id } };
    }
    if (hash.startsWith("#/snippets/edit/")) {
      const id = hash.substring("#/snippets/edit/".length);
      return { name: "edit-snippet", params: { id } };
    }

    return { name: "home", params: {} };
  };

  const route = parseRoute();

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 font-sans antialiased text-slate-900 selection:bg-indigo-500 selection:text-white">
      {/* Dynamic Header */}
      <Navbar 
        user={authState.user} 
        onLogout={handleLogout} 
        currentRoute={route.name} 
        navigate={navigate} 
      />

      {/* Main Page Layout */}
      <main className="flex-grow transition-opacity duration-300">
        {route.name === "home" && (
          <Home 
            user={authState.user} 
            token={authState.token} 
            navigate={navigate} 
          />
        )}
        {route.name === "login" && (
          <Login 
            onLoginSuccess={handleLoginSuccess} 
            navigate={navigate} 
          />
        )}
        {route.name === "register" && (
          <Register 
            navigate={navigate} 
          />
        )}
        {route.name === "dashboard" && (
          <Dashboard 
            user={authState.user} 
            token={authState.token} 
            navigate={navigate} 
            onProfileUpdate={handleProfileUpdate} 
          />
        )}
        {route.name === "add-snippet" && (
          <AddSnippet 
            token={authState.token} 
            navigate={navigate} 
          />
        )}
        {route.name === "view-snippet" && (
          <ViewSnippet 
            id={route.params.id || ""} 
            token={authState.token} 
            currentUser={authState.user} 
            navigate={navigate} 
          />
        )}
        {route.name === "edit-snippet" && (
          <EditSnippet 
            id={route.params.id || ""} 
            token={authState.token} 
            navigate={navigate} 
          />
        )}
        {route.name === "admin" && (
          <AdminDashboard 
            token={authState.token} 
            currentUser={authState.user} 
            navigate={navigate} 
          />
        )}
      </main>

      {/* Persistent Footer */}
      <footer className="bg-slate-900 text-slate-400 py-8 border-t border-slate-800 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center sm:px-6 lg:px-8">
          <p className="text-xs">
            &copy; 2026 Online Code Snippet Manager. Crafted with Spring Boot Security (JWT) & React Redux Patterns.
          </p>
          <div className="flex justify-center space-x-6 mt-3 text-[11px] font-mono">
            <span className="hover:text-white transition-colors cursor-pointer">Java 17 JRE</span>
            <span className="text-slate-700">&bull;</span>
            <span className="hover:text-white transition-colors cursor-pointer">Spring Boot 3.2</span>
            <span className="text-slate-700">&bull;</span>
            <span className="hover:text-white transition-colors cursor-pointer">React 19 / Vite</span>
            <span className="text-slate-700">&bull;</span>
            <span className="hover:text-white transition-colors cursor-pointer">MySQL Connector</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
