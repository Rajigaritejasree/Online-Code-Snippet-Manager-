import React from "react";
import { Code2, LogOut, Shield, User as UserIcon, LayoutDashboard, Plus, Home as HomeIcon } from "lucide-react";
import { User } from "../types";

interface NavbarProps {
  user: User | null;
  onLogout: () => void;
  currentRoute: string;
  navigate: (path: string) => void;
}

export default function Navbar({ user, onLogout, currentRoute, navigate }: NavbarProps) {
  return (
    <nav className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Left brand logo & links */}
          <div className="flex items-center space-x-8">
            <button
              onClick={() => navigate("#/")}
              className="flex items-center space-x-2 focus:outline-none group"
              id="nav-logo"
            >
              <div className="p-2 bg-indigo-600 rounded-lg group-hover:bg-indigo-500 transition-colors">
                <Code2 className="h-5 w-5 text-white" />
              </div>
              <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-indigo-400 to-indigo-200 bg-clip-text text-transparent">
                CodeSnippet Manager
              </span>
            </button>

            {/* Navigation links */}
            <div className="hidden md:flex space-x-2">
              <button
                onClick={() => navigate("#/")}
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                  currentRoute === "home"
                    ? "bg-slate-800 text-indigo-400"
                    : "text-slate-300 hover:bg-slate-800 hover:text-white"
                }`}
                id="nav-home"
              >
                <HomeIcon className="h-4 w-4" />
                <span>Home</span>
              </button>

              {user && (
                <>
                  <button
                    onClick={() => navigate("#/dashboard")}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                      currentRoute === "dashboard"
                        ? "bg-slate-800 text-indigo-400"
                        : "text-slate-300 hover:bg-slate-800 hover:text-white"
                    }`}
                    id="nav-dashboard"
                  >
                    <LayoutDashboard className="h-4 w-4" />
                    <span>My Dashboard</span>
                  </button>

                  <button
                    onClick={() => navigate("#/snippets/add")}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                      currentRoute === "add-snippet"
                        ? "bg-slate-800 text-indigo-400"
                        : "text-slate-300 hover:bg-slate-800 hover:text-white"
                    }`}
                    id="nav-add"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Add Snippet</span>
                  </button>
                </>
              )}

              {user && user.role === "ADMIN" && (
                <button
                  onClick={() => navigate("#/admin")}
                  className={`px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                    currentRoute === "admin"
                      ? "bg-slate-800 text-red-400"
                      : "text-slate-300 hover:bg-slate-800 hover:text-white"
                  }`}
                  id="nav-admin"
                >
                  <Shield className="h-4 w-4 text-red-400" />
                  <span>Admin Panel</span>
                </button>
              )}
            </div>
          </div>

          {/* Right auth details */}
          <div className="flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-4">
                <div className="hidden lg:flex flex-col text-right">
                  <span className="text-sm font-medium text-slate-100">{user.username}</span>
                  <span className="text-xs text-slate-400 capitalize flex items-center justify-end space-x-1">
                    {user.role === "ADMIN" && (
                      <span className="inline-block h-2 w-2 rounded-full bg-red-500 mr-1 animate-pulse"></span>
                    )}
                    {user.role}
                  </span>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => navigate("#/dashboard")}
                    className="p-1.5 bg-slate-800 rounded-full hover:bg-slate-700 transition-colors border border-slate-700 text-slate-300 hover:text-white"
                    title="View Profile"
                    id="profile-btn"
                  >
                    <UserIcon className="h-4 w-4" />
                  </button>

                  <button
                    onClick={onLogout}
                    className="flex items-center space-x-1 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-md text-sm font-medium text-slate-300 hover:text-white hover:bg-red-950 hover:border-red-800 transition-colors"
                    id="logout-btn"
                  >
                    <LogOut className="h-4 w-4" />
                    <span className="hidden sm:inline">Logout</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => navigate("#/login")}
                  className="px-4 py-2 text-sm font-medium text-slate-300 hover:text-white transition-colors"
                  id="nav-login"
                >
                  Sign In
                </button>
                <button
                  onClick={() => navigate("#/register")}
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-500 rounded-md shadow-sm transition-colors"
                  id="nav-register"
                >
                  Get Started
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Nav Helper Links */}
      {user && (
        <div className="md:hidden flex justify-around py-2 border-t border-slate-800 bg-slate-900/50">
          <button
            onClick={() => navigate("#/")}
            className={`text-xs font-medium px-2 py-1 ${
              currentRoute === "home" ? "text-indigo-400" : "text-slate-400"
            }`}
          >
            Home
          </button>
          <button
            onClick={() => navigate("#/dashboard")}
            className={`text-xs font-medium px-2 py-1 ${
              currentRoute === "dashboard" ? "text-indigo-400" : "text-slate-400"
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => navigate("#/snippets/add")}
            className={`text-xs font-medium px-2 py-1 ${
              currentRoute === "add-snippet" ? "text-indigo-400" : "text-slate-400"
            }`}
          >
            + Add
          </button>
          {user.role === "ADMIN" && (
            <button
              onClick={() => navigate("#/admin")}
              className={`text-xs font-medium px-2 py-1 ${
                currentRoute === "admin" ? "text-red-400" : "text-slate-400"
              }`}
            >
              Admin
            </button>
          )}
        </div>
      )}
    </nav>
  );
}
