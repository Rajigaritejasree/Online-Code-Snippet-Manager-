import React, { useState, useEffect } from "react";
import { Code2, ArrowLeft, Plus, Sparkles, Tag, CheckSquare, Save } from "lucide-react";
import axios from "axios";

interface AddSnippetProps {
  token: string | null;
  navigate: (path: string) => void;
}

export default function AddSnippet({ token, navigate }: AddSnippetProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [programmingLanguage, setProgrammingLanguage] = useState("Java");
  const [codeContent, setCodeContent] = useState("");
  const [category, setCategory] = useState("Java");
  const [categories, setCategories] = useState<string[]>(["Java", "Python", "SQL", "Web Development", "Data Structures"]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const languages = ["Java", "Python", "SQL", "JavaScript", "TypeScript", "HTML/CSS", "C++", "Go", "Rust", "Other"];

  useEffect(() => {
    if (!token) {
      navigate("#/login");
      return;
    }
    fetchCategories();
  }, [token]);

  const fetchCategories = async () => {
    try {
      const res = await axios.get("/api/categories", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCategories(res.data);
      if (res.data.length > 0) {
        setCategory(res.data[0]);
      }
    } catch (err) {
      console.error("Failed to load backend categories, defaulting to static lists.", err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!title.trim() || !codeContent.trim() || !category) {
      setError("Please complete all required fields (Title, Code, and Category)");
      return;
    }

    setLoading(true);
    try {
      const payload = {
        title: title.trim(),
        description: description.trim(),
        programmingLanguage,
        codeContent,
        category,
      };

      await axios.post("/api/snippets", payload, {
        headers: { Authorization: `Bearer ${token}` },
      });

      navigate("#/dashboard");
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.error || "Error adding snippet to database. Please check connection.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen py-10 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Back navigation */}
        <button
          onClick={() => navigate("#/dashboard")}
          className="flex items-center space-x-1.5 text-slate-500 hover:text-slate-800 transition-colors mb-6 text-sm font-semibold cursor-pointer"
          id="back-to-dashboard-btn"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Dashboard</span>
        </button>

        {/* Title header */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 flex items-center">
              <Code2 className="h-5 w-5 mr-2 text-indigo-600" />
              <span>Log New Code Snippet</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Store reusable modules, algorithms, and configurations securely inside your index.
            </p>
          </div>
          <Sparkles className="h-6 w-6 text-indigo-400 hidden sm:block" />
        </div>

        {/* Form Container */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-8">
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-xs text-center font-semibold mb-6">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Title */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Snippet Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Binary Search implementation, Spring Security CSRF bypass..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                required
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Description / Usage Notes
              </label>
              <textarea
                placeholder="Write a clear explanation of how the snippet works, inputs, outputs, or complex configurations..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-none"
              ></textarea>
            </div>

            {/* Language & Category Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Programming Language */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                  Programming Language
                </label>
                <div className="relative">
                  <select
                    value={programmingLanguage}
                    onChange={(e) => setProgrammingLanguage(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                  >
                    {languages.map((l) => (
                      <option key={l} value={l}>
                        {l}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                  Concept Category <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                  >
                    {categories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Code Content */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center justify-between">
                <span>Code Content <span className="text-red-500">*</span></span>
                <span className="text-[10px] font-mono text-slate-400 capitalize">Monospace Field</span>
              </label>
              <textarea
                placeholder={`e.g.\npublic class BubbleSort {\n    void sort(int arr[]) {\n        ...\n    }\n}`}
                value={codeContent}
                onChange={(e) => setCodeContent(e.target.value)}
                rows={12}
                className="w-full px-4 py-3 bg-slate-950 text-slate-300 border border-slate-800 rounded-lg font-mono text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 leading-relaxed text-left"
                required
              ></textarea>
            </div>

            {/* Action buttons */}
            <div className="flex space-x-3 pt-4 border-t border-slate-100">
              <button
                type="submit"
                disabled={loading}
                className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-400 text-white font-semibold rounded-lg shadow-md transition-all text-sm flex items-center justify-center space-x-2 cursor-pointer"
                id="submit-snippet-btn"
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    <span>Save to Database</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={() => navigate("#/dashboard")}
                className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold rounded-lg text-sm transition-all"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
