import React, { useState, useEffect } from "react";
import { User, Snippet } from "../types";
import { 
  Users, 
  Trash2, 
  Plus, 
  FolderLock, 
  FileCode, 
  ShieldAlert, 
  Tag, 
  Check, 
  UserX, 
  ArrowRight,
  Info 
} from "lucide-react";
import axios from "axios";

interface AdminDashboardProps {
  token: string | null;
  currentUser: User | null;
  navigate: (path: string) => void;
}

interface AdminUserRow {
  id: string;
  username: string;
  email: string;
  role: string;
  bio: string;
  snippetsCount: number;
}

export default function AdminDashboard({ token, currentUser, navigate }: AdminDashboardProps) {
  const [users, setUsers] = useState<AdminUserRow[]>([]);
  const [snippets, setSnippets] = useState<Snippet[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  
  // Tab control
  const [activeTab, setActiveTab] = useState<"users" | "snippets" | "categories">("users");

  // New Category form
  const [newCategory, setNewCategory] = useState("");
  const [catError, setCatError] = useState<string | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!token) {
      navigate("#/login");
      return;
    }
    if (currentUser && currentUser.role !== "ADMIN") {
      navigate("#/");
      return;
    }
    fetchAdminData();
  }, [token, currentUser, activeTab]);

  const fetchAdminData = async () => {
    setLoading(true);
    setError(null);
    try {
      const headers = { Authorization: `Bearer ${token}` };

      if (activeTab === "users") {
        const res = await axios.get("/api/admin/users", { headers });
        setUsers(res.data);
      } else if (activeTab === "snippets") {
        const res = await axios.get("/api/snippets", { headers });
        setSnippets(res.data);
      } else if (activeTab === "categories") {
        const res = await axios.get("/api/categories", { headers });
        setCategories(res.data);
      }
    } catch (err: any) {
      console.error(err);
      setError("Failed to fetch administrative data. Admin privileges required.");
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (id: string, name: string) => {
    if (id === currentUser?.id) {
      alert("Self-deletion is forbidden!");
      return;
    }

    if (!window.confirm(`Are you sure you want to permanently delete user "${name}"?\nAll associated code snippets will be deleted.`)) {
      return;
    }

    try {
      await axios.delete(`/api/admin/users/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers(users.filter((u) => u.id !== id));
    } catch (err: any) {
      console.error(err);
      alert("Error removing user: " + (err.response?.data?.error || err.message));
    }
  };

  const handleDeleteSnippet = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this snippet? (Admin Override)")) {
      return;
    }

    try {
      await axios.delete(`/api/snippets/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSnippets(snippets.filter((s) => s.id !== id));
    } catch (err) {
      console.error(err);
      alert("Error removing snippet.");
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    setCatError(null);

    const name = newCategory.trim();
    if (!name) {
      setCatError("Category name cannot be empty.");
      return;
    }

    try {
      const res = await axios.post(
        "/api/categories",
        { category: name },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setCategories(res.data);
      setNewCategory("");
    } catch (err: any) {
      console.error(err);
      setCatError(err.response?.data?.error || "Error adding category.");
    }
  };

  const handleDeleteCategory = async (name: string) => {
    if (!window.confirm(`Are you sure you want to delete category "${name}"?`)) {
      return;
    }

    try {
      const res = await axios.delete(`/api/categories/${name}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCategories(res.data);
    } catch (err: any) {
      console.error(err);
      alert("Error deleting category. It might be locked.");
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800" id="admin-panel-container">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        
        {/* Header banner */}
        <div className="bg-slate-900 text-white rounded-xl border border-slate-800 shadow-md p-6 mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight flex items-center">
              <FolderLock className="h-6 w-6 mr-2 text-red-400" />
              <span>System Administration Panel</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1">
              Override database snippets, configure categorizations, and delete accounts securely.
            </p>
          </div>
          <div className="flex items-center space-x-2 px-3 py-1 bg-red-500/10 border border-red-500/20 text-red-400 rounded-full text-xs font-semibold">
            <ShieldAlert className="h-4 w-4" />
            <span>Root Administrator Modes</span>
          </div>
        </div>

        {/* Admin Navigation Tabs */}
        <div className="flex border-b border-slate-200 mb-8 gap-2">
          <button
            onClick={() => setActiveTab("users")}
            className={`px-5 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center space-x-2 ${
              activeTab === "users"
                ? "border-indigo-600 text-indigo-600 font-bold"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Users className="h-4 w-4" />
            <span>User Accounts ({users.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("snippets")}
            className={`px-5 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center space-x-2 ${
              activeTab === "snippets"
                ? "border-indigo-600 text-indigo-600 font-bold"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <FileCode className="h-4 w-4" />
            <span>All Snippets ({snippets.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("categories")}
            className={`px-5 py-3 text-xs font-bold uppercase tracking-wider border-b-2 transition-all flex items-center space-x-2 ${
              activeTab === "categories"
                ? "border-indigo-600 text-indigo-600 font-bold"
                : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            <Tag className="h-4 w-4" />
            <span>Category Library ({categories.length})</span>
          </button>
        </div>

        {/* Error banner */}
        {error && (
          <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm mb-6 font-semibold">
            {error}
          </div>
        )}

        {/* Tab Contents */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden p-6">
          {loading ? (
            <div className="py-20 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
              <p className="text-xs text-slate-500 mt-3">Loading audited datasets...</p>
            </div>
          ) : (
            <>
              {/* Users Tab */}
              {activeTab === "users" && (
                <div>
                  <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center">
                    Registered Developer Accounts
                  </h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 font-bold uppercase">
                          <th className="px-6 py-3">Account Details</th>
                          <th className="px-6 py-3">Email Address</th>
                          <th className="px-6 py-3">Designation / Role</th>
                          <th className="px-6 py-3">Snippets Count</th>
                          <th className="px-6 py-3 text-right">Delete</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium">
                        {users.map((row) => (
                          <tr key={row.id} className="hover:bg-slate-50/50">
                            <td className="px-6 py-4">
                              <div className="flex items-center space-x-3">
                                <div className="h-8 w-8 bg-slate-100 text-slate-700 font-semibold rounded-full flex items-center justify-center">
                                  {row.username.substring(0, 2).toUpperCase()}
                                </div>
                                <div>
                                  <p className="font-bold text-slate-900">{row.username}</p>
                                  <p className="text-[10px] text-slate-400">{row.id}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-slate-600">{row.email}</td>
                            <td className="px-6 py-4">
                              <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold ${
                                row.role === "ADMIN" 
                                  ? "bg-red-50 text-red-700 border border-red-100" 
                                  : "bg-slate-100 text-slate-600 border border-slate-200"
                              }`}>
                                {row.role}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-slate-900 font-bold">{row.snippetsCount} items</td>
                            <td className="px-6 py-4 text-right">
                              <button
                                onClick={() => handleDeleteUser(row.id, row.username)}
                                disabled={row.id === currentUser?.id}
                                className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded disabled:opacity-30 cursor-pointer"
                                title="Purge Account"
                              >
                                <UserX className="h-4 w-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Snippets Tab */}
              {activeTab === "snippets" && (
                <div>
                  <h3 className="text-lg font-bold text-slate-900 mb-4">Auditing System Snippets</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 font-bold uppercase">
                          <th className="px-6 py-3">Snippet Title</th>
                          <th className="px-6 py-3">Language</th>
                          <th className="px-6 py-3">Category</th>
                          <th className="px-6 py-3">Author</th>
                          <th className="px-6 py-3 text-right font-bold">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium">
                        {snippets.map((row) => (
                          <tr key={row.id} className="hover:bg-slate-50/50">
                            <td className="px-6 py-4">
                              <div>
                                <p className="font-bold text-slate-900 text-sm">{row.title}</p>
                                <p className="text-slate-400 text-xs mt-0.5 line-clamp-1 font-normal">
                                  {row.description || "No description provided."}
                                </p>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <span className="font-mono bg-slate-100 px-2 py-0.5 rounded border border-slate-200 font-semibold">
                                {row.programmingLanguage}
                              </span>
                            </td>
                            <td className="px-6 py-4">
                              <span className="bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full font-semibold">
                                {row.category}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-slate-600">{row.authorName || "Anonymous"}</td>
                            <td className="px-6 py-4 text-right">
                              <div className="flex items-center justify-end space-x-1">
                                <button
                                  onClick={() => navigate(`#/snippets/view/${row.id}`)}
                                  className="px-2 py-1 bg-slate-100 text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 rounded transition-colors text-[11px] font-bold"
                                >
                                  Inspect
                                </button>
                                <button
                                  onClick={() => handleDeleteSnippet(row.id)}
                                  className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                                  title="Delete Snippet"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Categories Tab */}
              {activeTab === "categories" && (
                <div>
                  <h3 className="text-lg font-bold text-slate-900 mb-6">Database Category Classifications</h3>
                  
                  {/* Grid layout */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    
                    {/* Add Category Form */}
                    <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 h-fit">
                      <h4 className="text-sm font-bold text-slate-800 mb-4 flex items-center">
                        <Plus className="h-4 w-4 mr-1 text-indigo-600" /> Register Category
                      </h4>

                      {catError && (
                        <div className="p-3 bg-red-50 border border-red-100 text-red-700 rounded-md text-xs mb-4 font-semibold">
                          {catError}
                        </div>
                      )}

                      <form onSubmit={handleAddCategory} className="space-y-4">
                        <div>
                          <label className="block text-xs font-semibold uppercase text-slate-500 mb-1">
                            Category Classification Name
                          </label>
                          <input
                            type="text"
                            placeholder="e.g. AWS Cloud, Regular Expressions, Algorithms"
                            value={newCategory}
                            onChange={(e) => setNewCategory(e.target.value)}
                            className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            required
                          />
                        </div>
                        <button
                          type="submit"
                          className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-xs flex items-center justify-center space-x-1"
                        >
                          <Plus className="h-3.5 w-3.5" />
                          <span>Add Category</span>
                        </button>
                      </form>
                    </div>

                    {/* Active Categories List */}
                    <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
                      <div className="p-4 bg-slate-50 border-b border-slate-200 font-bold text-xs text-slate-600 uppercase tracking-wider flex justify-between">
                        <span>Active Categories</span>
                        <span>({categories.length} total)</span>
                      </div>
                      <div className="divide-y divide-slate-100 max-h-96 overflow-y-auto">
                        {categories.map((cat) => (
                          <div key={cat} className="p-3 flex justify-between items-center hover:bg-slate-50 transition-colors">
                            <span className="font-semibold text-slate-700 bg-indigo-50/50 border border-indigo-100/50 px-2.5 py-1 rounded-md text-xs">
                              {cat}
                            </span>
                            <button
                              onClick={() => handleDeleteCategory(cat)}
                              className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded cursor-pointer"
                              title="Delete Category"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
