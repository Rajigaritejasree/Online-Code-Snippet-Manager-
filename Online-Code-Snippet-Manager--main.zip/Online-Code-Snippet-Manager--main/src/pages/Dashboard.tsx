import React, { useState, useEffect } from "react";
import { User, Snippet } from "../types";
import { 
  User as UserIcon, 
  Terminal, 
  Tag, 
  Clock, 
  Eye, 
  Edit, 
  Trash2, 
  Plus, 
  FileText, 
  Sparkles, 
  Save, 
  Briefcase 
} from "lucide-react";
import axios from "axios";

interface DashboardProps {
  user: User | null;
  token: string | null;
  navigate: (path: string) => void;
  onProfileUpdate: (updatedUser: User) => void;
}

export default function Dashboard({ user, token, navigate, onProfileUpdate }: DashboardProps) {
  const [snippets, setSnippets] = useState<Snippet[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Profile Form States
  const [editMode, setEditMode] = useState(false);
  const [profileUsername, setProfileUsername] = useState("");
  const [profileBio, setProfileBio] = useState("");
  const [profileMessage, setProfileMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!token) {
      navigate("#/login");
      return;
    }
    if (user) {
      setProfileUsername(user.username);
      setProfileBio(user.bio || "");
    }
    fetchOwnSnippets();
  }, [token, user]);

  const fetchOwnSnippets = async () => {
    setLoading(true);
    try {
      const res = await axios.get("/api/snippets", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSnippets(res.data);
    } catch (err) {
      console.error(err);
      setError("Failed to load snippets.");
    } finally {
      setLoading(false);
    }
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileMessage(null);
    try {
      const res = await axios.put(
        "/api/users/profile",
        { username: profileUsername, bio: profileBio },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      
      onProfileUpdate(res.data.user);
      setProfileMessage("Profile updated successfully!");
      setEditMode(false);
      setTimeout(() => setProfileMessage(null), 3000);
    } catch (err: any) {
      console.error(err);
      setProfileMessage("Error updating profile: " + (err.response?.data?.error || err.message));
    }
  };

  const handleDeleteSnippet = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this code snippet? This action cannot be undone.")) {
      return;
    }

    try {
      await axios.delete(`/api/snippets/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSnippets(snippets.filter((s) => s.id !== id));
    } catch (err) {
      console.error(err);
      alert("Failed to delete snippet.");
    }
  };

  // Aggregated Stat Calculations
  const totalSnippets = snippets.length;
  const uniqueCategories = Array.from(new Set(snippets.map((s) => s.category))).length;
  
  // Calculate favorite language
  const languageCounts = snippets.reduce((acc: any, s) => {
    acc[s.programmingLanguage] = (acc[s.programmingLanguage] || 0) + 1;
    return acc;
  }, {});
  let favoriteLanguage = "None";
  let maxCount = 0;
  Object.keys(languageCounts).forEach((lang) => {
    if (languageCounts[lang] > maxCount) {
      maxCount = languageCounts[lang];
      favoriteLanguage = lang;
    }
  });

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800" id="dashboard-container">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Profile and Stats Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          
          {/* Profile Card */}
          <div className="lg:col-span-1 bg-white border border-slate-200 rounded-xl shadow-sm p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-50 rounded-bl-full -z-0"></div>
            
            <div className="relative z-10">
              <div className="flex items-center space-x-4 mb-6">
                <div className="h-16 w-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-xl shadow-md">
                  {user?.username?.substring(0, 2).toUpperCase() || "DE"}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-900">{user?.username}</h2>
                  <p className="text-xs text-slate-400 font-mono mt-0.5">{user?.email}</p>
                  <span className="inline-block px-2 py-0.5 bg-indigo-50 border border-indigo-100 text-indigo-700 text-[10px] font-bold rounded-full mt-2">
                    ROLE: {user?.role}
                  </span>
                </div>
              </div>

              {profileMessage && (
                <div className="p-3 bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-lg text-xs mb-4">
                  {profileMessage}
                </div>
              )}

              {!editMode ? (
                <div className="space-y-4">
                  <div>
                    <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">Developer Bio</h4>
                    <p className="text-sm text-slate-600 italic">
                      {user?.bio || "No developer bio set. Write a short bio detailing your stack!"}
                    </p>
                  </div>
                  <button
                    onClick={() => setEditMode(true)}
                    className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg text-xs transition-colors mt-2"
                    id="edit-profile-trigger"
                  >
                    Update Profile Info
                  </button>
                </div>
              ) : (
                <form onSubmit={handleProfileSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                      Display Name
                    </label>
                    <input
                      type="text"
                      value={profileUsername}
                      onChange={(e) => setProfileUsername(e.target.value)}
                      className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                      Developer Bio
                    </label>
                    <textarea
                      value={profileBio}
                      onChange={(e) => setProfileBio(e.target.value)}
                      rows={3}
                      placeholder="e.g. Frontend developer focusing on React and Java Spring Boot..."
                      className="w-full px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-slate-400 resize-none"
                    ></textarea>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      type="submit"
                      className="flex-1 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg text-xs flex items-center justify-center space-x-1"
                    >
                      <Save className="h-3 w-3" />
                      <span>Save Changes</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setEditMode(false);
                        setProfileUsername(user?.username || "");
                        setProfileBio(user?.bio || "");
                      }}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold rounded-lg text-xs"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>

          {/* Core Stats */}
          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col justify-between">
              <div>
                <span className="p-2.5 bg-indigo-50 text-indigo-600 rounded-lg inline-block mb-4">
                  <FileText className="h-5 w-5" />
                </span>
                <h4 className="text-sm font-semibold text-slate-500">My Saved Snippets</h4>
              </div>
              <div className="mt-4">
                <span className="text-3xl font-extrabold text-slate-900">{totalSnippets}</span>
                <span className="text-xs text-slate-400 block mt-1">Reusable items</span>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col justify-between">
              <div>
                <span className="p-2.5 bg-purple-50 text-purple-600 rounded-lg inline-block mb-4">
                  <Tag className="h-5 w-5" />
                </span>
                <h4 className="text-sm font-semibold text-slate-500">Indexed Categories</h4>
              </div>
              <div className="mt-4">
                <span className="text-3xl font-extrabold text-slate-900">{uniqueCategories}</span>
                <span className="text-xs text-slate-400 block mt-1">Active folder categories</span>
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-col justify-between">
              <div>
                <span className="p-2.5 bg-pink-50 text-pink-600 rounded-lg inline-block mb-4">
                  <Terminal className="h-5 w-5" />
                </span>
                <h4 className="text-sm font-semibold text-slate-500">Top Language</h4>
              </div>
              <div className="mt-4">
                <span className="text-2xl font-extrabold text-slate-900 truncate block">{favoriteLanguage}</span>
                <span className="text-xs text-slate-400 block mt-1">
                  {maxCount > 0 ? `${maxCount} snippets written` : "No language recorded"}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Snippets Table Section */}
        <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center">
                <Sparkles className="h-5 w-5 mr-2 text-indigo-600" />
                Manage Code Snippets
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Edit, delete, and inspect code blocks stored inside your library database account.
              </p>
            </div>
            <button
              onClick={() => navigate("#/snippets/add")}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-2 transition-colors cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Add New Snippet</span>
            </button>
          </div>

          {loading ? (
            <div className="py-20 text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600 mx-auto"></div>
              <p className="text-xs text-slate-500 mt-3">Loading snippets list...</p>
            </div>
          ) : snippets.length === 0 ? (
            <div className="py-16 text-center">
              <FileText className="h-10 w-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm font-bold text-slate-700">No Snippets Registered Yet</p>
              <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                Start logging your reusable functions, components, and code templates today.
              </p>
              <button
                onClick={() => navigate("#/snippets/add")}
                className="mt-4 px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium rounded-lg"
              >
                Create Snippet Now
              </button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 font-bold uppercase tracking-wider">
                    <th className="px-6 py-4">Title</th>
                    <th className="px-6 py-4">Language</th>
                    <th className="px-6 py-4">Category</th>
                    <th className="px-6 py-4">Date Logged</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {snippets.map((snip) => (
                    <tr key={snip.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div>
                          <p className="font-bold text-slate-900 text-sm">{snip.title}</p>
                          <p className="text-xs text-slate-400 font-normal line-clamp-1 mt-0.5">
                            {snip.description || "No description set"}
                          </p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 border border-slate-200 font-semibold font-mono">
                          {snip.programmingLanguage}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-semibold text-[11px]">
                          {snip.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-slate-500 font-normal">
                        <span className="flex items-center">
                          <Clock className="h-3.5 w-3.5 mr-1 text-slate-400" />
                          {new Date(snip.createdDate).toLocaleDateString(undefined, {
                            month: "short",
                            day: "numeric",
                            year: "numeric",
                          })}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => navigate(`#/snippets/view/${snip.id}`)}
                            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                            title="Inspect Details"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => navigate(`#/snippets/edit/${snip.id}`)}
                            className="p-1.5 text-slate-500 hover:text-amber-600 hover:bg-amber-50 rounded transition-colors"
                            title="Edit Snippet"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteSnippet(snip.id)}
                            className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                            title="Delete Snippet"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
