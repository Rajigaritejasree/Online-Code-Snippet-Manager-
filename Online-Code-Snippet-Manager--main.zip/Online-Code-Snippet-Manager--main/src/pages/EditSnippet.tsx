import React, { useState, useEffect } from "react";
import { ArrowLeft, Save, Sparkles, Code2 } from "lucide-react";
import { Snippet } from "../types";
import axios from "axios";

interface EditSnippetProps {
  id: string;
  token: string | null;
  navigate: (path: string) => void;
}

export default function EditSnippet({ id, token, navigate }: EditSnippetProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [programmingLanguage, setProgrammingLanguage] = useState("Java");
  const [codeContent, setCodeContent] = useState("");
  const [category, setCategory] = useState("Java");
  const [categories, setCategories] = useState<string[]>(["Java", "Python", "SQL", "Web Development", "Data Structures"]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const languages = ["Java", "Python", "SQL", "JavaScript", "TypeScript", "HTML/CSS", "C++", "Go", "Rust", "Other"];

  useEffect(() => {
    if (!token) {
      navigate("#/login");
      return;
    }
    fetchSnippetAndCategories();
  }, [id, token]);

  const fetchSnippetAndCategories = async () => {
    setLoading(true);
    setError(null);
    try {
      const headers = { Authorization: `Bearer ${token}` };

      // Fetch Categories
      const catRes = await axios.get("/api/categories", { headers });
      setCategories(catRes.data);

      // Fetch Snippet details
      const snipRes = await axios.get(`/api/snippets/${id}`, { headers });
      const snip: Snippet = snipRes.data;

      setTitle(snip.title);
      setDescription(snip.description || "");
      setProgrammingLanguage(snip.programmingLanguage);
      setCodeContent(snip.codeContent);
      setCategory(snip.category);
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.error || "Error loading snippet configurations.");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!title.trim() || !codeContent.trim() || !category) {
      setError("Please complete all required fields (Title, Code, and Category)");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        title: title.trim(),
        description: description.trim(),
        programmingLanguage,
        codeContent,
        category,
      };

      await axios.put(`/api/snippets/${id}`, payload, {
        headers: { Authorization: `Bearer ${token}` },
      });

      navigate(`#/snippets/view/${id}`);
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.error || "Error committing edits. Please check server.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
        <p className="text-sm text-slate-500 mt-4">Retrieving snippet details for editor...</p>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 min-h-screen py-10 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Back navigation */}
        <button
          onClick={() => navigate(`#/snippets/view/${id}`)}
          className="flex items-center space-x-1.5 text-slate-500 hover:text-slate-800 transition-colors mb-6 text-sm font-semibold cursor-pointer"
          id="back-to-details-btn"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Cancel & Back</span>
        </button>

        {/* Title header */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 flex items-center">
              <Code2 className="h-5 w-5 mr-2 text-indigo-600" />
              <span>Edit Code Snippet</span>
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              Modify properties, description context, programming languages, or source lines.
            </p>
          </div>
          <Sparkles className="h-6 w-6 text-indigo-400 hidden sm:block" />
        </div>

        {/* Form Container */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-8">
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-xs text-center font-semibold mb-6">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Title */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Snippet Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="e.g. Binary Search implementation, Spring Security CSRF bypass..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                required
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                Description / Usage Notes
              </label>
              <textarea
                placeholder="Write a clear explanation of how the snippet works, inputs, outputs, or complex configurations..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-none"
              ></textarea>
            </div>

            {/* Language & Category Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Programming Language */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                  Programming Language
                </label>
                <div className="relative">
                  <select
                    value={programmingLanguage}
                    onChange={(e) => setProgrammingLanguage(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                  >
                    {languages.map((l) => (
                      <option key={l} value={l}>
                        {l}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5">
                  Concept Category <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                  >
                    {categories.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Code Content */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center justify-between">
                <span>Code Content <span className="text-red-500">*</span></span>
                <span className="text-[10px] font-mono text-slate-400 capitalize">Monospace Field</span>
              </label>
              <textarea
                placeholder="e.g. public static void main(String[] args)..."
                value={codeContent}
                onChange={(e) => setCodeContent(e.target.value)}
                rows={12}
                className="w-full px-4 py-3 bg-slate-950 text-slate-300 border border-slate-800 rounded-lg font-mono text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 leading-relaxed text-left"
                required
              ></textarea>
            </div>

            {/* Action buttons */}
            <div className="flex space-x-3 pt-4 border-t border-slate-100">
              <button
                type="submit"
                disabled={saving}
                className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-400 text-white font-semibold rounded-lg shadow-md transition-all text-sm flex items-center justify-center space-x-2 cursor-pointer"
                id="update-save-btn"
              >
                {saving ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <>
                    <Save className="h-4 w-4" />
                    <span>Save Snippet Edits</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={() => navigate(`#/snippets/view/${id}`)}
                className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 font-semibold rounded-lg text-sm transition-all"
              >
                Cancel Changes
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
