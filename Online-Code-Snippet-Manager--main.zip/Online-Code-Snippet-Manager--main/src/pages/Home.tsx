import React, { useState, useEffect } from "react";
import { Search, Code2, Copy, Check, Filter, Terminal, BookOpen, Clock, Tag, ArrowRight } from "lucide-react";
import { Snippet, User } from "../types";
import axios from "axios";

interface HomeProps {
  user: User | null;
  token: string | null;
  navigate: (path: string) => void;
}

export default function Home({ user, token, navigate }: HomeProps) {
  const [snippets, setSnippets] = useState<Snippet[]>([]);
  const [categories, setCategories] = useState<string[]>(["Java", "Python", "SQL", "Web Development", "Data Structures"]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLang, setSelectedLang] = useState("");
  const [selectedCat, setSelectedCat] = useState("");
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Default mock teaser snippets to display on landing page for guest users
  const guestTeaserSnippets: Snippet[] = [
    {
      id: "teaser-1",
      title: "Binary Search Tree Insertion",
      description: "Standard recursive insertion algorithm for a binary search tree in Java.",
      programmingLanguage: "Java",
      codeContent: `public Node insert(Node root, int key) {\n    if (root == null) {\n        root = new Node(key);\n        return root;\n    }\n    if (key < root.key)\n        root.left = insert(root.left, key);\n    else if (key > root.key)\n        root.right = insert(root.right, key);\n    return root;\n}`,
      category: "Data Structures",
      createdDate: new Date().toISOString(),
      userId: "guest",
      authorName: "System",
    },
    {
      id: "teaser-2",
      title: "Quick Sort Implementation",
      description: "Efficient divide-and-conquer sorting method.",
      programmingLanguage: "Python",
      codeContent: `def quicksort(arr):\n    if len(arr) <= 1:\n        return arr\n    pivot = arr[len(arr) // 2]\n    left = [x for x in arr if x < pivot]\n    middle = [x for x in arr if x == pivot]\n    right = [x for x in arr if x > pivot]\n    return quicksort(left) + middle + quicksort(right)`,
      category: "Data Structures",
      createdDate: new Date().toISOString(),
      userId: "guest",
      authorName: "System",
    },
    {
      id: "teaser-3",
      title: "SQL Join Query with Grouping",
      description: "Aggregate salaries by department with left joins.",
      programmingLanguage: "SQL",
      codeContent: `SELECT d.name AS department, COUNT(e.id) AS employees, AVG(e.salary) AS avg_salary\nFROM departments d\nLEFT JOIN employees e ON d.id = e.department_id\nGROUP BY d.name\nHAVING employees > 5\nORDER BY avg_salary DESC;`,
      category: "SQL",
      createdDate: new Date().toISOString(),
      userId: "guest",
      authorName: "DatabaseAdmin",
    },
  ];

  const languages = ["Java", "Python", "SQL", "JavaScript", "TypeScript", "HTML/CSS", "C++", "Go", "Rust", "Other"];

  useEffect(() => {
    if (token) {
      fetchSnippetsAndCategories();
    } else {
      setSnippets(guestTeaserSnippets);
    }
  }, [token]);

  const fetchSnippetsAndCategories = async () => {
    setLoading(true);
    setError(null);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      
      // Fetch categories
      const catRes = await axios.get("/api/categories", { headers });
      setCategories(catRes.data);

      // Fetch snippets
      const snipRes = await axios.get("/api/snippets", { headers });
      setSnippets(snipRes.data);
    } catch (err: any) {
      console.error(err);
      setError("Failed to fetch library snippets. Please check server.");
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!token) return; // Teaser snippets are static, no backend query needed

    setLoading(true);
    setError(null);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const params = {
        query: searchQuery,
        language: selectedLang,
        category: selectedCat,
      };
      const res = await axios.get("/api/snippets/search", { headers, params });
      setSnippets(res.data);
    } catch (err: any) {
      console.error(err);
      setError("Search query execution failed.");
    } finally {
      setLoading(false);
    }
  };

  // Trigger search on select filters
  useEffect(() => {
    if (token) {
      handleSearch();
    }
  }, [selectedLang, selectedCat]);

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedLang("");
    setSelectedCat("");
    if (token) {
      fetchSnippetsAndCategories();
    } else {
      setSnippets(guestTeaserSnippets);
    }
  };

  const copyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredTeasers = snippets.filter((s) => {
    if (token) return true; // Handled by backend search API
    // Basic local filter for teaser guest view
    const matchQuery =
      !searchQuery ||
      s.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchLang = !selectedLang || s.programmingLanguage.toLowerCase() === selectedLang.toLowerCase();
    const matchCat = !selectedCat || s.category.toLowerCase() === selectedCat.toLowerCase();
    return matchQuery && matchLang && matchCat;
  });

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800" id="home-page-container">
      {/* Hero Header */}
      {!token ? (
        <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white py-20 px-4 text-center border-b border-slate-800">
          <div className="max-w-4xl mx-auto">
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-indigo-500/10 border border-indigo-500/30 rounded-full text-indigo-400 text-sm mb-6">
              <Code2 className="h-4 w-4" />
              <span>Version 1.0 Spring Boot + React Stack</span>
            </div>
            <h1 className="text-4xl sm:text-6xl font-bold tracking-tight mb-6">
              Organize, Search, & Share Your{" "}
              <span className="bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                Reusable Code Snippets
              </span>
            </h1>
            <p className="text-lg sm:text-xl text-slate-300 max-w-2xl mx-auto mb-8">
              A professional repository designed for developers to manage key software snippets, queries, algorithms, and boilerplate codes seamlessly.
            </p>
            <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
              <button
                onClick={() => navigate("#/register")}
                className="w-full sm:w-auto px-8 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold rounded-lg shadow-lg hover:shadow-indigo-500/10 transition-all flex items-center justify-center space-x-2"
                id="hero-register-btn"
              >
                <span>Create Free Account</span>
                <ArrowRight className="h-4 w-4" />
              </button>
              <button
                onClick={() => navigate("#/login")}
                className="w-full sm:w-auto px-8 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold rounded-lg transition-all"
                id="hero-login-btn"
              >
                Sign In to Library
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-slate-900 text-white py-10 border-b border-slate-800 px-4">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
                Welcome back, <span className="text-indigo-400">{user?.username}</span>
              </h1>
              <p className="text-sm text-slate-400 mt-1">
                {user?.role === "ADMIN" 
                  ? "Logged in as Administrator. You have system-wide management permission." 
                  : "Logged in. Manage, search and review your private code snippets."}
              </p>
            </div>
            <button
              onClick={() => navigate("#/snippets/add")}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-md text-sm font-semibold flex items-center space-x-2 transition-all shadow-md shadow-indigo-600/10"
              id="hero-add-snippet-btn"
            >
              <Code2 className="h-4 w-4" />
              <span>Add Code Snippet</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Search & Filter section */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-6 mb-8">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Search Query */}
              <div className="flex-1 relative">
                <Search className="absolute left-3.5 top-3.5 h-5 w-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search by title, description or code content..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                  id="search-input-field"
                />
              </div>

              {/* Language Selector */}
              <div className="w-full lg:w-48">
                <select
                  value={selectedLang}
                  onChange={(e) => setSelectedLang(e.target.value)}
                  className="w-full px-3 py-3 bg-slate-50 border border-slate-300 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                  id="language-select-dropdown"
                >
                  <option value="">All Languages</option>
                  {languages.map((l) => (
                    <option key={l} value={l}>
                      {l}
                    </option>
                  ))}
                </select>
              </div>

              {/* Category Selector */}
              <div className="w-full lg:w-48">
                <select
                  value={selectedCat}
                  onChange={(e) => setSelectedCat(e.target.value)}
                  className="w-full px-3 py-3 bg-slate-50 border border-slate-300 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-sm"
                  id="category-select-dropdown"
                >
                  <option value="">All Categories</option>
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              {/* Search Trigger Button */}
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 lg:flex-none px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-sm font-semibold flex items-center justify-center space-x-2 transition-all cursor-pointer"
                  id="execute-search-btn"
                >
                  <Search className="h-4 w-4" />
                  <span>Search</span>
                </button>

                {(searchQuery || selectedLang || selectedCat) && (
                  <button
                    type="button"
                    onClick={clearFilters}
                    className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-sm font-semibold transition-all"
                    id="clear-search-btn"
                    title="Reset Filters"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>
          </form>

          {/* Quick Language Tags */}
          <div className="flex flex-wrap gap-2 mt-4 items-center">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 mr-2 flex items-center">
              <Filter className="h-3 w-3 mr-1" /> Quick Filter Language:
            </span>
            {["Java", "Python", "SQL", "JavaScript"].map((lang) => (
              <button
                key={lang}
                onClick={() => setSelectedLang(selectedLang === lang ? "" : lang)}
                className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                  selectedLang === lang
                    ? "bg-indigo-600 text-white"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                }`}
              >
                {lang}
              </button>
            ))}
          </div>
        </div>

        {/* Error Notification */}
        {error && (
          <div className="p-4 bg-red-50 border-l-4 border-red-500 text-red-700 rounded-md mb-8 text-sm flex items-center shadow-sm">
            <span>{error}</span>
          </div>
        )}

        {/* Snippets Grid */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-slate-900 flex items-center">
              <Terminal className="h-5 w-5 mr-2 text-indigo-600" />
              <span>{token ? "My Code Library" : "Example Snippets Showcase"}</span>
              <span className="ml-2.5 px-2.5 py-0.5 bg-slate-200 text-slate-700 rounded-full text-xs font-semibold">
                {token ? filteredTeasers.length : filteredTeasers.length} Items
              </span>
            </h2>
            {!token && (
              <span className="text-xs text-indigo-600 font-medium">
                * Sign up to add and personalize your own snippets
              </span>
            )}
          </div>

          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 bg-white border border-slate-200 rounded-xl">
              <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
              <span className="text-sm text-slate-500 mt-4 font-medium">Fetching library snippets...</span>
            </div>
          ) : filteredTeasers.length === 0 ? (
            <div className="py-20 text-center bg-white border border-slate-200 rounded-xl shadow-sm">
              <Code2 className="h-12 w-12 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-slate-800">No Snippets Found</h3>
              <p className="text-sm text-slate-500 max-w-md mx-auto mt-1">
                There are no snippets matching your query parameters. Try widening your search or create a new snippet!
              </p>
              {token && (
                <button
                  onClick={() => navigate("#/snippets/add")}
                  className="mt-5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-semibold transition-all shadow-sm"
                >
                  Create Your First Snippet
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredTeasers.map((snippet) => (
                <div
                  key={snippet.id}
                  className="bg-white border border-slate-200 rounded-xl hover:border-indigo-200 hover:shadow-lg transition-all flex flex-col overflow-hidden"
                >
                  {/* Card Header */}
                  <div className="p-5 border-b border-slate-100 flex-1">
                    <div className="flex items-start justify-between">
                      <div>
                        {/* Title */}
                        <h3 className="text-lg font-bold text-slate-900 group-hover:text-indigo-600">
                          {snippet.title}
                        </h3>
                        {/* Description */}
                        <p className="text-sm text-slate-600 mt-1 line-clamp-2">
                          {snippet.description || "No description provided."}
                        </p>
                      </div>
                    </div>

                    {/* Metadata tags */}
                    <div className="flex flex-wrap gap-2 mt-3 items-center">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100">
                        <Tag className="h-3 w-3 mr-1" />
                        {snippet.category}
                      </span>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-100 text-slate-700 border border-slate-200">
                        <Code2 className="h-3 w-3 mr-1" />
                        {snippet.programmingLanguage}
                      </span>
                    </div>
                  </div>

                  {/* Code Editor Preview Window */}
                  <div className="relative group">
                    <div className="absolute right-3 top-3 z-10 flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => copyCode(snippet.codeContent, snippet.id)}
                        className="p-1.5 bg-slate-800 text-slate-300 hover:text-white rounded border border-slate-700 transition-colors"
                        title="Copy Code"
                      >
                        {copiedId === snippet.id ? <Check className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5" />}
                      </button>
                    </div>

                    <pre className="bg-slate-950 p-4 overflow-x-auto text-xs font-mono text-slate-300 leading-relaxed border-t border-b border-slate-800 max-h-48 text-left">
                      <code>{snippet.codeContent}</code>
                    </pre>
                  </div>

                  {/* Card Footer Actions */}
                  <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center">
                        <Clock className="h-3.5 w-3.5 mr-1" />
                        {new Date(snippet.createdDate).toLocaleDateString(undefined, {
                          month: "short",
                          day: "numeric",
                          year: "numeric",
                        })}
                      </span>
                      {snippet.authorName && (
                        <span className="flex items-center">
                          <BookOpen className="h-3.5 w-3.5 mr-1" />
                          By {snippet.authorName}
                        </span>
                      )}
                    </div>

                    <div className="flex space-x-2">
                      <button
                        onClick={() => {
                          if (token) {
                            navigate(`#/snippets/view/${snippet.id}`);
                          } else {
                            navigate("#/login");
                          }
                        }}
                        className="px-3 py-1.5 text-indigo-600 hover:bg-indigo-50 font-semibold rounded-md transition-colors"
                      >
                        View Full Details
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Feature Grid Section (Teaser for Guest user) */}
        {!token && (
          <div className="mt-20 border-t border-slate-200 pt-16">
            <h2 className="text-3xl font-bold text-center text-slate-900 tracking-tight mb-12">
              Why use CodeSnippet Manager?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-xl border border-slate-200">
                <div className="h-10 w-10 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center mb-4 font-bold">
                  1
                </div>
                <h3 className="font-bold text-lg text-slate-900 mb-2">Centralized Architecture</h3>
                <p className="text-slate-600 text-sm">
                  Never lose a custom regex query, system API controller, or array algorithm again. Keep all snippets indexed and searchable in a secure web dashboard.
                </p>
              </div>

              <div className="bg-white p-6 rounded-xl border border-slate-200">
                <div className="h-10 w-10 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center mb-4 font-bold">
                  2
                </div>
                <h3 className="font-bold text-lg text-slate-900 mb-2">Structured Cataloging</h3>
                <p className="text-slate-600 text-sm">
                  Map snippets with detailed category parameters (Java, Python, SQL) and custom descriptions for easier utility lookup when programming.
                </p>
              </div>

              <div className="bg-white p-6 rounded-xl border border-slate-200">
                <div className="h-10 w-10 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center mb-4 font-bold">
                  3
                </div>
                <h3 className="font-bold text-lg text-slate-900 mb-2">Role Based Security</h3>
                <p className="text-slate-600 text-sm">
                  Leverages Spring Boot Security and stateless JWT token exchanges to guarantee complete privacy of catalogued snippets.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
