import React, { useState } from "react";
import { Code2, Mail, Lock, Eye, EyeOff, Info } from "lucide-react";
import axios from "axios";
import { User } from "../types";

interface LoginProps {
  onLoginSuccess: (token: string, user: User) => void;
  navigate: (path: string) => void;
}

export default function Login({ onLoginSuccess, navigate }: LoginProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email || !password) {
      setError("Please fill in all fields");
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post("/api/auth/login", { email, password });
      const { token, user } = response.data;
      
      onLoginSuccess(token, user);
      navigate("#/");
    } catch (err: any) {
      console.error(err);
      if (err.response && err.response.data && err.response.data.error) {
        setError(err.response.data.error);
      } else {
        setError("Invalid email or password. Please verify that the database server is running.");
      }
    } finally {
      setLoading(false);
    }
  };

  const autofill = (role: "USER" | "ADMIN") => {
    if (role === "ADMIN") {
      setEmail("admin@snippet.com");
      setPassword("admin123");
    } else {
      setEmail("user@snippet.com");
      setPassword("user123");
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen py-16 px-4 flex flex-col items-center justify-center">
      <div className="max-w-md w-full bg-white rounded-xl border border-slate-200 shadow-lg p-8">
        <div className="text-center mb-8">
          <div className="inline-flex p-3 bg-indigo-50 border border-indigo-100 text-indigo-600 rounded-xl mb-4">
            <Code2 className="h-6 w-6" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">Sign In</h2>
          <p className="text-sm text-slate-500 mt-1">Access your saved snippets dashboard</p>
        </div>

        {error && (
          <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-xs text-center font-semibold mb-4">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <span className="absolute left-3 top-3.5 text-slate-400">
                <Mail className="h-4.5 w-4.5" />
              </span>
              <input
                type="email"
                placeholder="developer@snippet.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                required
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
              Password
            </label>
            <div className="relative">
              <span className="absolute left-3 top-3.5 text-slate-400">
                <Lock className="h-4.5 w-4.5" />
              </span>
              <input
                type={showPassword ? "text" : "password"}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3.5 text-slate-400 hover:text-slate-600 focus:outline-none"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-400 text-white font-semibold rounded-lg shadow-md transition-all text-sm mt-2 flex items-center justify-center space-x-2"
          >
            {loading ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            ) : (
              <span>Sign In</span>
            )}
          </button>

          <div className="text-center text-xs text-slate-500 mt-4">
            Don't have an account?{" "}
            <button
              type="button"
              onClick={() => navigate("#/register")}
              className="text-indigo-600 font-semibold hover:underline"
            >
              Register Here
            </button>
          </div>
        </form>
      </div>

      {/* Quick Test Accounts panel */}
      <div className="max-w-md w-full mt-6 bg-indigo-50/50 border border-indigo-100 rounded-xl p-5 shadow-sm">
        <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-800 flex items-center mb-3">
          <Info className="h-4 w-4 mr-1.5 text-indigo-600" />
          Pre-seeded Test Accounts (Spring Security Roles)
        </h4>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => autofill("USER")}
            className="p-2 bg-white border border-indigo-200 hover:border-indigo-400 rounded-lg text-left text-xs transition-all cursor-pointer group"
          >
            <p className="font-semibold text-slate-800 group-hover:text-indigo-600">Standard Developer</p>
            <p className="text-slate-500 mt-0.5">Role: <span className="text-slate-700 font-medium">USER</span></p>
            <p className="text-[10px] text-slate-400 font-mono mt-1">user@snippet.com / user123</p>
          </button>

          <button
            onClick={() => autofill("ADMIN")}
            className="p-2 bg-white border border-red-200 hover:border-red-400 rounded-lg text-left text-xs transition-all cursor-pointer group"
          >
            <p className="font-semibold text-slate-800 group-hover:text-red-600">System Administrator</p>
            <p className="text-red-500 mt-0.5">Role: <span className="text-red-700 font-medium">ADMIN</span></p>
            <p className="text-[10px] text-slate-400 font-mono mt-1">admin@snippet.com / admin123</p>
          </button>
        </div>
      </div>
    </div>
  );
}
