import React, { useState } from "react";
import { Code2, UserPlus, Mail, Lock, Shield, Eye, EyeOff } from "lucide-react";
import axios from "axios";

interface RegisterProps {
  navigate: (path: string) => void;
}

export default function Register({ navigate }: RegisterProps) {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState("USER"); // Default role
  const [showPassword, setShowPassword] = useState(false);
  
  const [loading, setLoading] = useState(false);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [serverError, setServerError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationErrors([]);
    setServerError(null);

    const errors = [];
    if (username.trim().length < 3) {
      errors.push("Username must be at least 3 characters long");
    }
    if (!email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
      errors.push("Please provide a valid email address");
    }
    if (password.length < 6) {
      errors.push("Password must be at least 6 characters long");
    }
    if (password !== confirmPassword) {
      errors.push("Passwords do not match");
    }

    if (errors.length > 0) {
      setValidationErrors(errors);
      return;
    }

    setLoading(true);
    try {
      const payload = {
        username,
        email,
        password,
        role,
      };

      await axios.post("/api/auth/register", payload);
      setSuccess(true);
      setTimeout(() => {
        navigate("#/login");
      }, 2000);
    } catch (err: any) {
      console.error(err);
      if (err.response && err.response.data && err.response.data.error) {
        setServerError(err.response.data.error);
      } else {
        setServerError("Registration failed. Please verify that the backend is online.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen py-16 px-4 flex items-center justify-center">
      <div className="max-w-md w-full bg-white rounded-xl border border-slate-200 shadow-lg p-8">
        <div className="text-center mb-8">
          <div className="inline-flex p-3 bg-indigo-50 border border-indigo-100 text-indigo-600 rounded-xl mb-4">
            <Code2 className="h-6 w-6" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">Create Account</h2>
          <p className="text-sm text-slate-500 mt-1">Get started with Online Code Snippet Manager</p>
        </div>

        {success ? (
          <div className="p-4 bg-green-50 border border-green-200 text-green-700 rounded-lg text-center font-medium">
            <p className="text-sm">Registration successful!</p>
            <p className="text-xs text-green-600 mt-1">Redirecting to login...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Display validation issues */}
            {validationErrors.length > 0 && (
              <div className="p-4 bg-red-50 border border-red-100 text-red-700 rounded-lg text-xs space-y-1">
                {validationErrors.map((err, i) => (
                  <p key={i} className="flex items-center">
                    <span className="h-1.5 w-1.5 bg-red-500 rounded-full mr-2"></span>
                    {err}
                  </p>
                ))}
              </div>
            )}

            {/* Display Server Errors */}
            {serverError && (
              <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded-lg text-xs text-center font-semibold">
                {serverError}
              </div>
            )}

            {/* Username */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                Username
              </label>
              <div className="relative">
                <span className="absolute left-3 top-3.5 text-slate-400">
                  <UserPlus className="h-4.5 w-4.5" />
                </span>
                <input
                  type="text"
                  placeholder="johndoe"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                  required
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                Email Address
              </label>
              <div className="relative">
                <span className="absolute left-3 top-3.5 text-slate-400">
                  <Mail className="h-4.5 w-4.5" />
                </span>
                <input
                  type="email"
                  placeholder="john@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                Password
              </label>
              <div className="relative">
                <span className="absolute left-3 top-3.5 text-slate-400">
                  <Lock className="h-4.5 w-4.5" />
                </span>
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3.5 text-slate-400 hover:text-slate-600 focus:outline-none"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                Confirm Password
              </label>
              <div className="relative">
                <span className="absolute left-3 top-3.5 text-slate-400">
                  <Lock className="h-4.5 w-4.5" />
                </span>
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-lg text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
                  required
                />
              </div>
            </div>

            {/* Role Selection */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                Account Role (Simulate Spring Security Roles)
              </label>
              <div className="flex gap-4">
                <label className="flex-1 flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-100 transition-all">
                  <span className="text-xs font-semibold text-slate-700 flex items-center">
                    <UserPlus className="h-4 w-4 text-slate-500 mr-2" /> USER
                  </span>
                  <input
                    type="radio"
                    name="role"
                    value="USER"
                    checked={role === "USER"}
                    onChange={() => setRole("USER")}
                    className="text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                  />
                </label>
                <label className="flex-1 flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-100 transition-all">
                  <span className="text-xs font-semibold text-red-700 flex items-center">
                    <Shield className="h-4 w-4 text-red-500 mr-2" /> ADMIN
                  </span>
                  <input
                    type="radio"
                    name="role"
                    value="ADMIN"
                    checked={role === "ADMIN"}
                    onChange={() => setRole("ADMIN")}
                    className="text-red-600 focus:ring-red-500 h-4 w-4"
                  />
                </label>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-400 text-white font-semibold rounded-lg shadow-md transition-all text-sm mt-2 flex items-center justify-center space-x-2"
            >
              {loading ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
              ) : (
                <span>Register Account</span>
              )}
            </button>

            <div className="text-center text-xs text-slate-500 mt-4">
              Already have an account?{" "}
              <button
                type="button"
                onClick={() => navigate("#/login")}
                className="text-indigo-600 font-semibold hover:underline"
              >
                Sign In
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
