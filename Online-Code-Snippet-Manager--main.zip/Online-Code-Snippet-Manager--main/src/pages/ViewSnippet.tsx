import React, { useState, useEffect } from "react";
import { ArrowLeft, Edit, Copy, Check, Calendar, User as UserIcon, Tag, Terminal, Trash2 } from "lucide-react";
import { Snippet, User } from "../types";
import axios from "axios";

interface ViewSnippetProps {
  id: string;
  token: string | null;
  currentUser: User | null;
  navigate: (path: string) => void;
}

export default function ViewSnippet({ id, token, currentUser, navigate }: ViewSnippetProps) {
  const [snippet, setSnippet] = useState<Snippet | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!token) {
      navigate("#/login");
      return;
    }
    fetchSnippetDetails();
  }, [id, token]);

  const fetchSnippetDetails = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await axios.get(`/api/snippets/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setSnippet(res.data);
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.error || "Error retrieving snippet information from server.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!snippet) return;
    navigator.clipboard.writeText(snippet.codeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDelete = async () => {
    if (!snippet) return;
    if (!window.confirm("Are you sure you want to delete this snippet?")) return;

    try {
      await axios.delete(`/api/snippets/${snippet.id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      navigate("#/dashboard");
    } catch (err: any) {
      console.error(err);
      alert("Error deleting snippet: " + (err.response?.data?.error || err.message));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center py-20">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
        <p className="text-sm text-slate-500 mt-4">Retrieving code block metadata...</p>
      </div>
    );
  }

  if (error || !snippet) {
    return (
      <div className="min-h-screen bg-slate-50 py-12 px-4">
        <div className="max-w-2xl mx-auto bg-white p-8 rounded-xl border border-slate-200 text-center shadow-md">
          <Terminal className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-800">Lookup Error</h2>
          <p className="text-sm text-slate-500 mt-2">{error || "The requested snippet details could not be found."}</p>
          <button
            onClick={() => navigate("#/dashboard")}
            className="mt-6 px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-sm font-semibold transition-all"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    );
  }

  const isOwnerOrAdmin = currentUser?.role === "ADMIN" || currentUser?.id === snippet.userId;

  return (
    <div className="bg-slate-50 min-h-screen py-10 px-4" id="view-snippet-container">
      <div className="max-w-4xl mx-auto">
        {/* Back row */}
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={() => navigate("#/dashboard")}
            className="flex items-center space-x-1.5 text-slate-500 hover:text-slate-800 transition-colors text-sm font-semibold cursor-pointer"
            id="back-list-btn"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Library</span>
          </button>

          {isOwnerOrAdmin && (
            <div className="flex space-x-2">
              <button
                onClick={() => navigate(`#/snippets/edit/${snippet.id}`)}
                className="px-4 py-2 bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-bold flex items-center space-x-1 shadow-sm transition-all cursor-pointer"
                id="edit-snippet-top-btn"
              >
                <Edit className="h-3.5 w-3.5" />
                <span>Edit Snippet</span>
              </button>
              <button
                onClick={handleDelete}
                className="px-4 py-2 bg-white border border-red-200 text-red-600 hover:bg-red-50 rounded-lg text-xs font-bold flex items-center space-x-1 shadow-sm transition-all cursor-pointer"
                id="delete-snippet-top-btn"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Delete</span>
              </button>
            </div>
          )}
        </div>

        {/* Snippet card */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-lg overflow-hidden mb-8">
          {/* Metadata banner */}
          <div className="p-6 border-b border-slate-100 bg-slate-50/50">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div>
                <h1 className="text-2xl font-bold text-slate-900 leading-tight">{snippet.title}</h1>
                <p className="text-sm text-slate-600 mt-1.5">
                  {snippet.description || "No description provided."}
                </p>
              </div>
            </div>

            {/* Badges row */}
            <div className="flex flex-wrap gap-3 mt-4 items-center text-xs text-slate-500">
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100 font-bold">
                <Tag className="h-3.5 w-3.5 mr-1" />
                {snippet.category}
              </span>
              <span className="inline-flex items-center px-3 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200 font-bold font-mono">
                <Terminal className="h-3.5 w-3.5 mr-1" />
                {snippet.programmingLanguage}
              </span>

              <div className="h-4 w-px bg-slate-200 hidden sm:block mx-1"></div>

              <span className="flex items-center">
                <Calendar className="h-4 w-4 mr-1 text-slate-400" />
                Logged: {new Date(snippet.createdDate).toLocaleDateString(undefined, {
                  month: "long",
                  day: "numeric",
                  year: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>

              {snippet.authorName && (
                <span className="flex items-center">
                  <UserIcon className="h-4 w-4 mr-1 text-slate-400" />
                  By {snippet.authorName}
                </span>
              )}
            </div>
          </div>

          {/* Full Code Container */}
          <div className="relative group">
            {/* Floating actions */}
            <div className="absolute right-4 top-4 z-10 flex space-x-2">
              <button
                onClick={handleCopy}
                className="px-4 py-2 bg-slate-800 text-slate-200 hover:text-white rounded-lg border border-slate-700 text-xs font-semibold flex items-center space-x-1.5 shadow transition-all cursor-pointer"
                title="Copy full script"
                id="copy-code-view-btn"
              >
                {copied ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-green-400" />
                    <span className="text-green-400">Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>

            {/* Display code content */}
            <pre className="bg-slate-950 p-6 overflow-x-auto text-xs sm:text-sm font-mono text-slate-300 leading-relaxed text-left min-h-96">
              <code>{snippet.codeContent}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
