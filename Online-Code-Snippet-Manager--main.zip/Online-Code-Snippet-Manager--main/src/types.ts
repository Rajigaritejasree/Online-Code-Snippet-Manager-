export interface User {
  id: string;
  username: string;
  email: string;
  role: "USER" | "ADMIN";
  bio?: string;
  snippetsCount?: number;
}

export interface Snippet {
  id: string;
  title: string;
  description: string;
  programmingLanguage: string;
  codeContent: string;
  category: string;
  createdDate: string;
  userId: string;
  authorName?: string;
}

export interface AuthState {
  token: string | null;
  user: User | null;
}
